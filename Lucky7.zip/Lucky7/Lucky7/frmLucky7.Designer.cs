﻿namespace Lucky7
{
    partial class frmLucky7
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLucky7));
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.lblNumero3 = new System.Windows.Forms.Label();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.btnExibir = new System.Windows.Forms.Button();
            this.btnFim = new System.Windows.Forms.Button();
            this.gbResumo = new System.Windows.Forms.GroupBox();
            this.pbSeteMonstrinhos = new System.Windows.Forms.PictureBox();
            this.lblExibirQuantidade = new System.Windows.Forms.Label();
            this.lblExibirAcertos = new System.Windows.Forms.Label();
            this.lblExibir = new System.Windows.Forms.Label();
            this.lblAcertos = new System.Windows.Forms.Label();
            this.gbResumo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSeteMonstrinhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero1.Location = new System.Drawing.Point(104, 28);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(37, 40);
            this.lblNumero1.TabIndex = 0;
            this.lblNumero1.Text = "0";
            this.lblNumero1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumero3
            // 
            this.lblNumero3.AutoSize = true;
            this.lblNumero3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumero3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero3.Location = new System.Drawing.Point(190, 28);
            this.lblNumero3.Name = "lblNumero3";
            this.lblNumero3.Size = new System.Drawing.Size(37, 40);
            this.lblNumero3.TabIndex = 1;
            this.lblNumero3.Text = "0";
            this.lblNumero3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumero2
            // 
            this.lblNumero2.AutoSize = true;
            this.lblNumero2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero2.Location = new System.Drawing.Point(147, 28);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(37, 40);
            this.lblNumero2.TabIndex = 2;
            this.lblNumero2.Text = "0";
            this.lblNumero2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExibir
            // 
            this.btnExibir.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExibir.Location = new System.Drawing.Point(12, 12);
            this.btnExibir.Name = "btnExibir";
            this.btnExibir.Size = new System.Drawing.Size(75, 36);
            this.btnExibir.TabIndex = 3;
            this.btnExibir.Text = "Exibir";
            this.btnExibir.UseVisualStyleBackColor = true;
            this.btnExibir.Click += new System.EventHandler(this.btnExibir_Click);
            // 
            // btnFim
            // 
            this.btnFim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFim.Location = new System.Drawing.Point(12, 63);
            this.btnFim.Name = "btnFim";
            this.btnFim.Size = new System.Drawing.Size(75, 36);
            this.btnFim.TabIndex = 4;
            this.btnFim.Text = "Fim";
            this.btnFim.UseVisualStyleBackColor = true;
            this.btnFim.Click += new System.EventHandler(this.btnFim_Click);
            // 
            // gbResumo
            // 
            this.gbResumo.Controls.Add(this.pbSeteMonstrinhos);
            this.gbResumo.Controls.Add(this.lblExibirQuantidade);
            this.gbResumo.Controls.Add(this.lblExibirAcertos);
            this.gbResumo.Controls.Add(this.lblExibir);
            this.gbResumo.Controls.Add(this.lblAcertos);
            this.gbResumo.Location = new System.Drawing.Point(13, 105);
            this.gbResumo.Name = "gbResumo";
            this.gbResumo.Size = new System.Drawing.Size(317, 132);
            this.gbResumo.TabIndex = 5;
            this.gbResumo.TabStop = false;
            this.gbResumo.Text = "Resumo";
            this.gbResumo.Enter += new System.EventHandler(this.gbResumo_Enter);
            // 
            // pbSeteMonstrinhos
            // 
            this.pbSeteMonstrinhos.Image = ((System.Drawing.Image)(resources.GetObject("pbSeteMonstrinhos.Image")));
            this.pbSeteMonstrinhos.Location = new System.Drawing.Point(177, 16);
            this.pbSeteMonstrinhos.Name = "pbSeteMonstrinhos";
            this.pbSeteMonstrinhos.Size = new System.Drawing.Size(123, 107);
            this.pbSeteMonstrinhos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSeteMonstrinhos.TabIndex = 3;
            this.pbSeteMonstrinhos.TabStop = false;
            this.pbSeteMonstrinhos.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblExibirQuantidade
            // 
            this.lblExibirQuantidade.AutoSize = true;
            this.lblExibirQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibirQuantidade.ForeColor = System.Drawing.Color.Red;
            this.lblExibirQuantidade.Location = new System.Drawing.Point(77, 43);
            this.lblExibirQuantidade.Name = "lblExibirQuantidade";
            this.lblExibirQuantidade.Size = new System.Drawing.Size(19, 20);
            this.lblExibirQuantidade.TabIndex = 2;
            this.lblExibirQuantidade.Text = "0";
            // 
            // lblExibirAcertos
            // 
            this.lblExibirAcertos.AutoSize = true;
            this.lblExibirAcertos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibirAcertos.ForeColor = System.Drawing.Color.Blue;
            this.lblExibirAcertos.Location = new System.Drawing.Point(77, 20);
            this.lblExibirAcertos.Name = "lblExibirAcertos";
            this.lblExibirAcertos.Size = new System.Drawing.Size(19, 20);
            this.lblExibirAcertos.TabIndex = 1;
            this.lblExibirAcertos.Text = "0";
            this.lblExibirAcertos.Click += new System.EventHandler(this.lblExibirAcertos_Click);
            // 
            // lblExibir
            // 
            this.lblExibir.AutoSize = true;
            this.lblExibir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExibir.ForeColor = System.Drawing.Color.Red;
            this.lblExibir.Location = new System.Drawing.Point(7, 43);
            this.lblExibir.Name = "lblExibir";
            this.lblExibir.Size = new System.Drawing.Size(58, 20);
            this.lblExibir.TabIndex = 0;
            this.lblExibir.Text = "Exibir:";
            // 
            // lblAcertos
            // 
            this.lblAcertos.AutoSize = true;
            this.lblAcertos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAcertos.ForeColor = System.Drawing.Color.Blue;
            this.lblAcertos.Location = new System.Drawing.Point(7, 20);
            this.lblAcertos.Name = "lblAcertos";
            this.lblAcertos.Size = new System.Drawing.Size(76, 20);
            this.lblAcertos.TabIndex = 0;
            this.lblAcertos.Text = "Acertos:";
            this.lblAcertos.Click += new System.EventHandler(this.lblAcertos_Click);
            // 
            // frmLucky7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 243);
            this.Controls.Add(this.gbResumo);
            this.Controls.Add(this.btnFim);
            this.Controls.Add(this.btnExibir);
            this.Controls.Add(this.lblNumero2);
            this.Controls.Add(this.lblNumero3);
            this.Controls.Add(this.lblNumero1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmLucky7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lucky 7";
            this.gbResumo.ResumeLayout(false);
            this.gbResumo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSeteMonstrinhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label lblNumero3;
        private System.Windows.Forms.Label lblNumero2;
        private System.Windows.Forms.Button btnExibir;
        private System.Windows.Forms.Button btnFim;
        private System.Windows.Forms.GroupBox gbResumo;
        private System.Windows.Forms.PictureBox pbSeteMonstrinhos;
        private System.Windows.Forms.Label lblExibirQuantidade;
        private System.Windows.Forms.Label lblExibirAcertos;
        private System.Windows.Forms.Label lblExibir;
        private System.Windows.Forms.Label lblAcertos;
    }
}

