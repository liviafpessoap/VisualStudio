﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lucky7
{
    public partial class frmLucky7 : Form
    {
        int qtde = 0;
        int acertos = 0;

        public frmLucky7()
        {
            InitializeComponent();
        }

        private void btnFim_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Fim do aplicativo", "Lucky", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Application.Exit();
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            Random randomico = new Random(); // Classe característica = instancia
            // lblNumero1.Text = randomico.Next(10).ToString();
            // lblNumero1.Text = numero1.ToString();
            int numero1 = randomico.Next(10);
            int numero2 = randomico.Next(10);
            int numero3 = randomico.Next(10);

            lblNumero1.Text = numero1.ToString();
            lblNumero2.Text = numero2.ToString();
            lblNumero3.Text = numero3.ToString();

            if (numero1 == 7 || numero2 == 7 || numero3 == 7)
            {
                pbSeteMonstrinhos.Visible = true;
                acertos += 1;
            }
            else
            {
                pbSeteMonstrinhos.Visible = false;
            }
            qtde += 1;

            lblExibirQuantidade.Text = qtde.ToString();
            lblExibirAcertos.Text = acertos.ToString();
        }

        private void gbResumo_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void lblAcertos_Click(object sender, EventArgs e)
        {

        }

        private void lblExibirAcertos_Click(object sender, EventArgs e)
        {

        }
    }
}
