﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soma_2_Números
{
    public partial class frmSoma2Numeros : Form
    {
        public frmSoma2Numeros()
        {
            InitializeComponent();
        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblNumero2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double numero1 = 0, numero2 = 0;
            numero1 = Convert.ToDouble(txtNumero1.Text);
            numero2 = Convert.ToDouble(txtNumero2.Text);

            double calcular = numero1 + numero2;
            txtResultado.Text = calcular.ToString();

            txtResultado.Clear(); // apagar
            txtNumero1.Focus(); // volta pra linha sem precisar clicar

        }

        private void frmSoma2Numeros_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Sair do aplicativo");
            Application.Exit();
        }
    }
}
