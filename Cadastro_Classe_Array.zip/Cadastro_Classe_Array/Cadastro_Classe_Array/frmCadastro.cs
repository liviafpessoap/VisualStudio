﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_Classe_Array
{
    public partial class frmCadastro : Form
    {
        private List<clsCadastro> cadastro = new List<clsCadastro>();

        public frmCadastro()
        {
            InitializeComponent();
            IniciarGrid();
        }

        private void frmCadastro_Load(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = false; // Desabilita o botão novo
            btnSalvar.Enabled = true; // Habilita o botão salvar
            txtCodigo.Focus(); // Coloca o foco na caixa de texto do código
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnSalvar.Enabled = false;
            btnNovo.Enabled = true;

            var codigo = Convert.ToInt16(txtCodigo.Text);
            var nome = txtNome.Text;
            var idade = Convert.ToInt16(txtIdade.Text);
            var uf = cmbUF.Text;

            var objCadastro = new clsCadastro
            {
                Codigo = codigo,
                Nome = nome,
                Idade = idade,
                UF = uf
            };

            cadastro.Add(objCadastro);
            AtualizarGrid();

        }

        private void AtualizarGrid()
        {
            dgvCadastro.Rows.Clear();
            foreach (var cadastros in cadastro)
            {
                dgvCadastro.Rows.Add(cadastros.Codigo, cadastros.Nome, cadastros.Idade, cadastros.UF);
            }
        }

        private void IniciarGrid()
        {
            dgvCadastro.ColumnCount = 4;
            dgvCadastro.Columns[0].Name = "Código";
            dgvCadastro.Columns[1].Name = "Nome";
            dgvCadastro.Columns[2].Name = "Idade";
            dgvCadastro.Columns[3].Name = "UF";
        }
    }
}
