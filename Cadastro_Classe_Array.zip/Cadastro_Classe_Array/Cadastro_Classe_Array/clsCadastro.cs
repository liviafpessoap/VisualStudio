﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Classe_Array
{
    internal class clsCadastro
    {
        private int codigo;
        private string nome;
        private int idade;
        private string uf;

        // Encapsular - Gerar as propriedades
        public int Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public int Idade
        {
            get { return idade; }
            set { idade = value; }
        }

        public string UF
        {
            get { return uf; }
            set { uf = value; }
        }
    }
}
