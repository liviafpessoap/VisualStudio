﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculoPrecoVenda
{
    public partial class frmPrecoVenda : Form
    {
        public frmPrecoVenda()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtCusto_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tem certeza?", "Saindo do aplicativo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Clear();
            cmbDescricao.SelectedIndex = -1;
            txtCusto.Clear();
            txtPercentualAumento.Clear();
            txtPrecoVenda.Clear();
            txtCodigo.Focus();
        }

        private void frmPrecoVenda_Load(object sender, EventArgs e)
        {
            cmbDescricao.Items.Add("Camiseta Adidas");
            cmbDescricao.Items.Add("Calça Calvin Klein");
            cmbDescricao.Items.Add("Tênis New Balance");
            cmbDescricao.Items.Add("Bermuda da Balenciaga");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double custo = 0, PercentualAumento = 0, PrecoVenda = 0;

            // convertendo as caixas de texto para as variáveis
            custo = Convert.ToDouble(txtCusto.Text);
            PercentualAumento = Convert.ToDouble(txtPercentualAumento.Text);

            // calculando o preço de venda
            PrecoVenda = custo + (custo + PercentualAumento) / 100;

            txtPrecoVenda.Text = PrecoVenda.ToString();
        }
    }
}
