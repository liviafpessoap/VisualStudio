﻿namespace CalculoPrecoVenda
{
    partial class frmPrecoVenda
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbDados = new System.Windows.Forms.GroupBox();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtCusto = new System.Windows.Forms.TextBox();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.lblCusto = new System.Windows.Forms.Label();
            this.lblPercentualAumento = new System.Windows.Forms.Label();
            this.cmbDescricao = new System.Windows.Forms.ComboBox();
            this.gbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblPrecoVEnda = new System.Windows.Forms.Label();
            this.txtPrecoVenda = new System.Windows.Forms.TextBox();
            this.txtPercentualAumento = new System.Windows.Forms.TextBox();
            this.gbDados.SuspendLayout();
            this.gbOpcoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbDados
            // 
            this.gbDados.Controls.Add(this.cmbDescricao);
            this.gbDados.Controls.Add(this.txtCodigo);
            this.gbDados.Controls.Add(this.txtPercentualAumento);
            this.gbDados.Controls.Add(this.txtCusto);
            this.gbDados.Controls.Add(this.lblPercentualAumento);
            this.gbDados.Controls.Add(this.lblCodigo);
            this.gbDados.Controls.Add(this.lblDescricao);
            this.gbDados.Controls.Add(this.lblCusto);
            this.gbDados.Font = new System.Drawing.Font("SimSun-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDados.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbDados.Location = new System.Drawing.Point(12, 12);
            this.gbDados.Name = "gbDados";
            this.gbDados.Size = new System.Drawing.Size(327, 133);
            this.gbDados.TabIndex = 0;
            this.gbDados.TabStop = false;
            this.gbDados.Text = "Dados";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(30, 30);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(62, 16);
            this.lblCodigo.TabIndex = 0;
            this.lblCodigo.Text = "Código:";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(98, 27);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(60, 23);
            this.txtCodigo.TabIndex = 1;
            // 
            // txtCusto
            // 
            this.txtCusto.Location = new System.Drawing.Point(98, 86);
            this.txtCusto.Name = "txtCusto";
            this.txtCusto.Size = new System.Drawing.Size(60, 23);
            this.txtCusto.TabIndex = 2;
            this.txtCusto.TextChanged += new System.EventHandler(this.txtCusto_TextChanged);
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Location = new System.Drawing.Point(8, 59);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(84, 16);
            this.lblDescricao.TabIndex = 3;
            this.lblDescricao.Text = "Descrição:";
            this.lblDescricao.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblCusto
            // 
            this.lblCusto.AutoSize = true;
            this.lblCusto.Location = new System.Drawing.Point(37, 89);
            this.lblCusto.Name = "lblCusto";
            this.lblCusto.Size = new System.Drawing.Size(55, 16);
            this.lblCusto.TabIndex = 4;
            this.lblCusto.Text = "Custo:";
            this.lblCusto.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblPercentualAumento
            // 
            this.lblPercentualAumento.AutoSize = true;
            this.lblPercentualAumento.Location = new System.Drawing.Point(164, 89);
            this.lblPercentualAumento.Name = "lblPercentualAumento";
            this.lblPercentualAumento.Size = new System.Drawing.Size(87, 16);
            this.lblPercentualAumento.TabIndex = 5;
            this.lblPercentualAumento.Text = "% Aumento:";
            // 
            // cmbDescricao
            // 
            this.cmbDescricao.FormattingEnabled = true;
            this.cmbDescricao.Location = new System.Drawing.Point(98, 56);
            this.cmbDescricao.Name = "cmbDescricao";
            this.cmbDescricao.Size = new System.Drawing.Size(219, 24);
            this.cmbDescricao.TabIndex = 6;
            // 
            // gbOpcoes
            // 
            this.gbOpcoes.Controls.Add(this.btnSair);
            this.gbOpcoes.Controls.Add(this.btnCalcular);
            this.gbOpcoes.Controls.Add(this.btnLimpar);
            this.gbOpcoes.Font = new System.Drawing.Font("SimSun-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbOpcoes.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbOpcoes.Location = new System.Drawing.Point(12, 151);
            this.gbOpcoes.Name = "gbOpcoes";
            this.gbOpcoes.Size = new System.Drawing.Size(327, 83);
            this.gbOpcoes.TabIndex = 7;
            this.gbOpcoes.TabStop = false;
            this.gbOpcoes.Text = "Opções";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(191)))));
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcular.Location = new System.Drawing.Point(19, 28);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(86, 32);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(191)))));
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Location = new System.Drawing.Point(120, 28);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(86, 32);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(191)))));
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Location = new System.Drawing.Point(221, 28);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(86, 32);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblPrecoVEnda
            // 
            this.lblPrecoVEnda.AutoSize = true;
            this.lblPrecoVEnda.Font = new System.Drawing.Font("SimSun-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoVEnda.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPrecoVEnda.Location = new System.Drawing.Point(48, 243);
            this.lblPrecoVEnda.Name = "lblPrecoVEnda";
            this.lblPrecoVEnda.Size = new System.Drawing.Size(125, 16);
            this.lblPrecoVEnda.TabIndex = 9;
            this.lblPrecoVEnda.Text = "Preço de Venda:";
            // 
            // txtPrecoVenda
            // 
            this.txtPrecoVenda.Font = new System.Drawing.Font("SimSun-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecoVenda.Location = new System.Drawing.Point(179, 240);
            this.txtPrecoVenda.Name = "txtPrecoVenda";
            this.txtPrecoVenda.Size = new System.Drawing.Size(100, 23);
            this.txtPrecoVenda.TabIndex = 10;
            // 
            // txtPercentualAumento
            // 
            this.txtPercentualAumento.Location = new System.Drawing.Point(257, 86);
            this.txtPercentualAumento.Name = "txtPercentualAumento";
            this.txtPercentualAumento.Size = new System.Drawing.Size(60, 23);
            this.txtPercentualAumento.TabIndex = 8;
            // 
            // frmPrecoVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(126)))), ((int)(((byte)(130)))));
            this.ClientSize = new System.Drawing.Size(355, 275);
            this.Controls.Add(this.txtPrecoVenda);
            this.Controls.Add(this.lblPrecoVEnda);
            this.Controls.Add(this.gbOpcoes);
            this.Controls.Add(this.gbDados);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPrecoVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cálculo do Preço de Venda";
            this.Load += new System.EventHandler(this.frmPrecoVenda_Load);
            this.gbDados.ResumeLayout(false);
            this.gbDados.PerformLayout();
            this.gbOpcoes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbDados;
        private System.Windows.Forms.Label lblPercentualAumento;
        private System.Windows.Forms.Label lblCusto;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.TextBox txtCusto;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.ComboBox cmbDescricao;
        private System.Windows.Forms.TextBox txtPercentualAumento;
        private System.Windows.Forms.GroupBox gbOpcoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblPrecoVEnda;
        private System.Windows.Forms.TextBox txtPrecoVenda;
    }
}

