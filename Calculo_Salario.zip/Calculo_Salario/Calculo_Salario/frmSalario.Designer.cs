﻿namespace Calculo_Salario
{
    partial class frmSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpDados = new System.Windows.Forms.GroupBox();
            this.cmbCargo = new System.Windows.Forms.ComboBox();
            this.txtPercentualAumento = new System.Windows.Forms.TextBox();
            this.txtFuncionario = new System.Windows.Forms.TextBox();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.txtBruto = new System.Windows.Forms.TextBox();
            this.lblPercentualAumento = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.gbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnExibir = new System.Windows.Forms.Button();
            this.bgResultado = new System.Windows.Forms.GroupBox();
            this.lblSalarioReceber = new System.Windows.Forms.Label();
            this.lblAumentoConcedido = new System.Windows.Forms.Label();
            this.btnNovo = new System.Windows.Forms.Button();
            this.gpDados.SuspendLayout();
            this.gbOpcoes.SuspendLayout();
            this.bgResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpDados
            // 
            this.gpDados.Controls.Add(this.cmbCargo);
            this.gpDados.Controls.Add(this.txtPercentualAumento);
            this.gpDados.Controls.Add(this.txtFuncionario);
            this.gpDados.Controls.Add(this.lblFuncionario);
            this.gpDados.Controls.Add(this.txtBruto);
            this.gpDados.Controls.Add(this.lblPercentualAumento);
            this.gpDados.Controls.Add(this.lblCargo);
            this.gpDados.Controls.Add(this.lblBruto);
            this.gpDados.Location = new System.Drawing.Point(12, 12);
            this.gpDados.Name = "gpDados";
            this.gpDados.Size = new System.Drawing.Size(297, 160);
            this.gpDados.TabIndex = 0;
            this.gpDados.TabStop = false;
            this.gpDados.Text = "Dados";
            // 
            // cmbCargo
            // 
            this.cmbCargo.FormattingEnabled = true;
            this.cmbCargo.Location = new System.Drawing.Point(9, 76);
            this.cmbCargo.Name = "cmbCargo";
            this.cmbCargo.Size = new System.Drawing.Size(282, 21);
            this.cmbCargo.TabIndex = 3;
            // 
            // txtPercentualAumento
            // 
            this.txtPercentualAumento.Location = new System.Drawing.Point(134, 124);
            this.txtPercentualAumento.Name = "txtPercentualAumento";
            this.txtPercentualAumento.Size = new System.Drawing.Size(72, 20);
            this.txtPercentualAumento.TabIndex = 2;
            // 
            // txtFuncionario
            // 
            this.txtFuncionario.Location = new System.Drawing.Point(9, 32);
            this.txtFuncionario.Name = "txtFuncionario";
            this.txtFuncionario.Size = new System.Drawing.Size(282, 20);
            this.txtFuncionario.TabIndex = 2;
            this.txtFuncionario.TextChanged += new System.EventHandler(this.txtFuncionario_TextChanged);
            // 
            // lblFuncionario
            // 
            this.lblFuncionario.AutoSize = true;
            this.lblFuncionario.Location = new System.Drawing.Point(6, 16);
            this.lblFuncionario.Name = "lblFuncionario";
            this.lblFuncionario.Size = new System.Drawing.Size(108, 13);
            this.lblFuncionario.TabIndex = 1;
            this.lblFuncionario.Text = "Nome do funcionário:";
            // 
            // txtBruto
            // 
            this.txtBruto.Location = new System.Drawing.Point(9, 124);
            this.txtBruto.Name = "txtBruto";
            this.txtBruto.Size = new System.Drawing.Size(72, 20);
            this.txtBruto.TabIndex = 2;
            // 
            // lblPercentualAumento
            // 
            this.lblPercentualAumento.AutoSize = true;
            this.lblPercentualAumento.Location = new System.Drawing.Point(131, 108);
            this.lblPercentualAumento.Name = "lblPercentualAumento";
            this.lblPercentualAumento.Size = new System.Drawing.Size(115, 13);
            this.lblPercentualAumento.TabIndex = 1;
            this.lblPercentualAumento.Text = "Percental de Aumento:";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(6, 60);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(38, 13);
            this.lblCargo.TabIndex = 1;
            this.lblCargo.Text = "Cargo:";
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.Location = new System.Drawing.Point(6, 108);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(69, 13);
            this.lblBruto.TabIndex = 1;
            this.lblBruto.Text = "Salario bruto:";
            // 
            // gbOpcoes
            // 
            this.gbOpcoes.Controls.Add(this.btnNovo);
            this.gbOpcoes.Controls.Add(this.btnSair);
            this.gbOpcoes.Controls.Add(this.btnExibir);
            this.gbOpcoes.Location = new System.Drawing.Point(12, 188);
            this.gbOpcoes.Name = "gbOpcoes";
            this.gbOpcoes.Size = new System.Drawing.Size(297, 69);
            this.gbOpcoes.TabIndex = 1;
            this.gbOpcoes.TabStop = false;
            this.gbOpcoes.Text = "Opções:";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(216, 19);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 35);
            this.btnSair.TabIndex = 0;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnExibir
            // 
            this.btnExibir.Location = new System.Drawing.Point(9, 19);
            this.btnExibir.Name = "btnExibir";
            this.btnExibir.Size = new System.Drawing.Size(75, 35);
            this.btnExibir.TabIndex = 0;
            this.btnExibir.Text = "Exibir";
            this.btnExibir.UseVisualStyleBackColor = true;
            this.btnExibir.Click += new System.EventHandler(this.btnExibir_Click);
            // 
            // bgResultado
            // 
            this.bgResultado.Controls.Add(this.lblSalarioReceber);
            this.bgResultado.Controls.Add(this.lblAumentoConcedido);
            this.bgResultado.Location = new System.Drawing.Point(64, 263);
            this.bgResultado.Name = "bgResultado";
            this.bgResultado.Size = new System.Drawing.Size(200, 100);
            this.bgResultado.TabIndex = 2;
            this.bgResultado.TabStop = false;
            this.bgResultado.Text = "Resultado";
            // 
            // lblSalarioReceber
            // 
            this.lblSalarioReceber.AutoSize = true;
            this.lblSalarioReceber.Location = new System.Drawing.Point(6, 57);
            this.lblSalarioReceber.Name = "lblSalarioReceber";
            this.lblSalarioReceber.Size = new System.Drawing.Size(0, 13);
            this.lblSalarioReceber.TabIndex = 1;
            // 
            // lblAumentoConcedido
            // 
            this.lblAumentoConcedido.AutoSize = true;
            this.lblAumentoConcedido.Location = new System.Drawing.Point(6, 28);
            this.lblAumentoConcedido.Name = "lblAumentoConcedido";
            this.lblAumentoConcedido.Size = new System.Drawing.Size(0, 13);
            this.lblAumentoConcedido.TabIndex = 0;
            // 
            // btnNovo
            // 
            this.btnNovo.Location = new System.Drawing.Point(114, 19);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(75, 35);
            this.btnNovo.TabIndex = 1;
            this.btnNovo.Text = "Novo";
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // frmSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 391);
            this.Controls.Add(this.bgResultado);
            this.Controls.Add(this.gbOpcoes);
            this.Controls.Add(this.gpDados);
            this.Name = "frmSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.frmSalario_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSalario_FormClosing);
            this.Load += new System.EventHandler(this.frmSalario_Load);
            this.gpDados.ResumeLayout(false);
            this.gpDados.PerformLayout();
            this.gbOpcoes.ResumeLayout(false);
            this.bgResultado.ResumeLayout(false);
            this.bgResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpDados;
        private System.Windows.Forms.ComboBox cmbCargo;
        private System.Windows.Forms.TextBox txtPercentualAumento;
        private System.Windows.Forms.TextBox txtFuncionario;
        private System.Windows.Forms.Label lblFuncionario;
        private System.Windows.Forms.TextBox txtBruto;
        private System.Windows.Forms.Label lblPercentualAumento;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblBruto;
        private System.Windows.Forms.GroupBox gbOpcoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnExibir;
        private System.Windows.Forms.GroupBox bgResultado;
        private System.Windows.Forms.Label lblSalarioReceber;
        private System.Windows.Forms.Label lblAumentoConcedido;
        private System.Windows.Forms.Button btnNovo;
    }
}

