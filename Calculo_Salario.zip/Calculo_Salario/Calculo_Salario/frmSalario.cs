﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_Salario
{
    public partial class frmSalario : Form
    {
        public frmSalario()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmSalario_Load(object sender, EventArgs e)
        {
            cmbCargo.Items.Add("Analista");
            cmbCargo.Items.Add("Programador");
            cmbCargo.Items.Add("Gerente");
            cmbCargo.Items.Add("CEO");
        }

        private void frmSalario_Activated(object sender, EventArgs e)
        {
            // MessageBox.Show("O formulário foi carregado");
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            double Bruto = 0, PercentualAumento = 0, AumentoConcedido = 0, SalarioReceber = 0;

            // Tentando converter o salário

            bool ESalario = double.TryParse(txtBruto.Text, out Bruto);
            if (!ESalario) // Se não conseguir converter
            {
                MessageBox.Show("Por favor, informe um valor válido");
                txtBruto.Focus();
                return;
            }

            bool EPercentual = double.TryParse(txtPercentualAumento.Text, out PercentualAumento);
            if (!EPercentual) // Se não conseguir converter
            {
                MessageBox.Show("Por favor, informe um valor válido");
                txtPercentualAumento.Focus();
                return;
            }

            // Convertendo as textbox para variável
            Bruto = Convert.ToDouble(txtBruto.Text);
            PercentualAumento = Convert.ToDouble(txtPercentualAumento.Text);

            // Calcular o valor do aumento
            AumentoConcedido = (Bruto * PercentualAumento) / 100;
            lblAumentoConcedido.Text = "O aumento concedido foi " + AumentoConcedido;

            // Calcular o salário a receber com o valor de aumento
            SalarioReceber = Bruto + AumentoConcedido;
            lblSalarioReceber.Text = "O salário com aumento é " + SalarioReceber;

            btnExibir.Enabled = false;
            btnNovo.Enabled = true;
        }

        private void frmSalario_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Não esqueça do backup!");

        }


        private void Limpar ()
        {
            txtFuncionario.Clear();
            cmbCargo.SelectedIndex = -1;
            txtBruto.Clear();
            txtPercentualAumento.Clear();
            lblAumentoConcedido.Text = "";
            lblSalarioReceber.Text = "";
        }

        private void txtFuncionario_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            Limpar(); // Carrega o método Limpar
            btnExibir.Enabled = true;
            btnNovo.Enabled = false;
        }
    }
}
