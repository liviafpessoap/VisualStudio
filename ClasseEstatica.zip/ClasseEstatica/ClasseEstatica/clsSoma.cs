﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseEstatica
{
    internal class clsSoma
    {
        private double numero1;
        private double numero2;

        public static double Somar(double Numero1, double Numero2)
        {
            return Numero1 + Numero2;
        }
    }
}
