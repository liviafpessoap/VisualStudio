﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseEstatica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nExemplo de Classe Estpatica");
            Console.Write("\nSoma de 2 números");
            double numero1 = 0, numero2 = 0;
            Console.Write("\nNúmero 1: ");
            numero1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nNúmero 2: ");
            numero2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("\nSoma: " + clsSoma.Somar(numero1, numero2));

            Console.ReadKey();
        }
    }
}
