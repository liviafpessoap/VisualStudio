﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Soma_2_Numeros
{
    internal class clsSoma
    {
        private int numero1; // Definição do atributo 1
        private int numero2; // Definição do atributo 2

        // Propriedades públicas para ter acesso aos atributos acima

        public int Numero1
        {
            get { return numero1; }
            set { numero1 = value; }
        }

        public int Numero2
        {
            get { return numero2; }
            set { numero2 = value; }
        }

        // Método para realizar a soma

        public int Somar (int numero1, int numero2)
        {
            return numero1 + numero2;
        }


    }
}
