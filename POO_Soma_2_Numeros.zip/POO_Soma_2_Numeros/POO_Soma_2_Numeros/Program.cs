﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Soma_2_Numeros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nProgramação Orientada a Objetos");
            Console.Write("\nSoma de 2 números");

            // Instanciando a classe clsSoma
            clsSoma objSoma = new clsSoma();

            // Solicita ao usuário os dois números
            Console.Write("\nInforme o número 1: ");
            int num1 = Convert.ToInt16(Console.ReadLine());

            Console.Write("\nInforme o número 2: ");
            int num2 = Convert.ToInt16(Console.ReadLine());

            // Realiza a soma e exibe o resultado
            int result = objSoma.Somar(num1, num2);
            Console.Write("\nA soma é: " + result);

            Console.ReadKey();
        }
    }
}
