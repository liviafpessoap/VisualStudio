﻿namespace Restaurante
{
    partial class frmRestaurante
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomePrato = new System.Windows.Forms.Label();
            this.txtNomePrato = new System.Windows.Forms.TextBox();
            this.lblIngredientes = new System.Windows.Forms.Label();
            this.lstIngredientes = new System.Windows.Forms.ListBox();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnNovoPrato = new System.Windows.Forms.Button();
            this.btnEspecial = new System.Windows.Forms.Button();
            this.lblPratoMontado = new System.Windows.Forms.Label();
            this.lstPratoMontado = new System.Windows.Forms.ListBox();
            this.grbLocal = new System.Windows.Forms.GroupBox();
            this.rdbViagem = new System.Windows.Forms.RadioButton();
            this.rdbComerAqui = new System.Windows.Forms.RadioButton();
            this.grbEmbalagem = new System.Windows.Forms.GroupBox();
            this.chkIsopor = new System.Windows.Forms.CheckBox();
            this.chkAluminio = new System.Windows.Forms.CheckBox();
            this.chkPlastica = new System.Windows.Forms.CheckBox();
            this.grbBebidas = new System.Windows.Forms.GroupBox();
            this.chkVinho = new System.Windows.Forms.CheckBox();
            this.chkCerveja = new System.Windows.Forms.CheckBox();
            this.chkRefrigerante = new System.Windows.Forms.CheckBox();
            this.chkSuco = new System.Windows.Forms.CheckBox();
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblTotalIngredientes = new System.Windows.Forms.Label();
            this.txtTotalIngredientes = new System.Windows.Forms.TextBox();
            this.lblTotalIngredientesPrato = new System.Windows.Forms.Label();
            this.txtTotalIngredientesPrato = new System.Windows.Forms.TextBox();
            this.grbLocal.SuspendLayout();
            this.grbEmbalagem.SuspendLayout();
            this.grbBebidas.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomePrato
            // 
            this.lblNomePrato.AutoSize = true;
            this.lblNomePrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePrato.Location = new System.Drawing.Point(1, 74);
            this.lblNomePrato.Name = "lblNomePrato";
            this.lblNomePrato.Size = new System.Drawing.Size(159, 25);
            this.lblNomePrato.TabIndex = 1;
            this.lblNomePrato.Text = "Nome do prato:";
            // 
            // txtNomePrato
            // 
            this.txtNomePrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomePrato.Location = new System.Drawing.Point(6, 102);
            this.txtNomePrato.Name = "txtNomePrato";
            this.txtNomePrato.Size = new System.Drawing.Size(780, 31);
            this.txtNomePrato.TabIndex = 2;
            // 
            // lblIngredientes
            // 
            this.lblIngredientes.AutoSize = true;
            this.lblIngredientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngredientes.Location = new System.Drawing.Point(1, 157);
            this.lblIngredientes.Name = "lblIngredientes";
            this.lblIngredientes.Size = new System.Drawing.Size(136, 25);
            this.lblIngredientes.TabIndex = 3;
            this.lblIngredientes.Text = "Ingredientes:";
            this.lblIngredientes.Click += new System.EventHandler(this.label1_Click);
            // 
            // lstIngredientes
            // 
            this.lstIngredientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstIngredientes.FormattingEnabled = true;
            this.lstIngredientes.ItemHeight = 25;
            this.lstIngredientes.Location = new System.Drawing.Point(6, 188);
            this.lstIngredientes.Name = "lstIngredientes";
            this.lstIngredientes.Size = new System.Drawing.Size(303, 254);
            this.lstIngredientes.TabIndex = 5;
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.Location = new System.Drawing.Point(315, 188);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(129, 34);
            this.btnAdicionar.TabIndex = 6;
            this.btnAdicionar.Text = "&Adicionar";
            this.btnAdicionar.UseVisualStyleBackColor = true;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Location = new System.Drawing.Point(315, 228);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(129, 34);
            this.btnExcluir.TabIndex = 7;
            this.btnExcluir.Text = "&Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnNovoPrato
            // 
            this.btnNovoPrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoPrato.Location = new System.Drawing.Point(315, 268);
            this.btnNovoPrato.Name = "btnNovoPrato";
            this.btnNovoPrato.Size = new System.Drawing.Size(129, 34);
            this.btnNovoPrato.TabIndex = 8;
            this.btnNovoPrato.Text = "&Novo Prato";
            this.btnNovoPrato.UseVisualStyleBackColor = true;
            this.btnNovoPrato.Click += new System.EventHandler(this.btnNovoPrato_Click);
            // 
            // btnEspecial
            // 
            this.btnEspecial.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspecial.Location = new System.Drawing.Point(315, 308);
            this.btnEspecial.Name = "btnEspecial";
            this.btnEspecial.Size = new System.Drawing.Size(129, 34);
            this.btnEspecial.TabIndex = 9;
            this.btnEspecial.Text = "E&special";
            this.btnEspecial.UseVisualStyleBackColor = true;
            this.btnEspecial.Click += new System.EventHandler(this.btnEspecial_Click);
            // 
            // lblPratoMontado
            // 
            this.lblPratoMontado.AutoSize = true;
            this.lblPratoMontado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPratoMontado.Location = new System.Drawing.Point(478, 157);
            this.lblPratoMontado.Name = "lblPratoMontado";
            this.lblPratoMontado.Size = new System.Drawing.Size(159, 25);
            this.lblPratoMontado.TabIndex = 10;
            this.lblPratoMontado.Text = "Prato Montado:";
            // 
            // lstPratoMontado
            // 
            this.lstPratoMontado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPratoMontado.FormattingEnabled = true;
            this.lstPratoMontado.ItemHeight = 25;
            this.lstPratoMontado.Location = new System.Drawing.Point(483, 188);
            this.lstPratoMontado.Name = "lstPratoMontado";
            this.lstPratoMontado.Size = new System.Drawing.Size(303, 254);
            this.lstPratoMontado.TabIndex = 11;
            // 
            // grbLocal
            // 
            this.grbLocal.Controls.Add(this.rdbViagem);
            this.grbLocal.Controls.Add(this.rdbComerAqui);
            this.grbLocal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbLocal.Location = new System.Drawing.Point(6, 506);
            this.grbLocal.Name = "grbLocal";
            this.grbLocal.Size = new System.Drawing.Size(154, 155);
            this.grbLocal.TabIndex = 12;
            this.grbLocal.TabStop = false;
            this.grbLocal.Text = "Local";
            // 
            // rdbViagem
            // 
            this.rdbViagem.AutoSize = true;
            this.rdbViagem.Location = new System.Drawing.Point(6, 54);
            this.rdbViagem.Name = "rdbViagem";
            this.rdbViagem.Size = new System.Drawing.Size(102, 29);
            this.rdbViagem.TabIndex = 14;
            this.rdbViagem.TabStop = true;
            this.rdbViagem.Text = "Viagem";
            this.rdbViagem.UseVisualStyleBackColor = true;
            this.rdbViagem.CheckedChanged += new System.EventHandler(this.rdbViagem_CheckedChanged);
            // 
            // rdbComerAqui
            // 
            this.rdbComerAqui.AutoSize = true;
            this.rdbComerAqui.Location = new System.Drawing.Point(6, 30);
            this.rdbComerAqui.Name = "rdbComerAqui";
            this.rdbComerAqui.Size = new System.Drawing.Size(140, 29);
            this.rdbComerAqui.TabIndex = 13;
            this.rdbComerAqui.TabStop = true;
            this.rdbComerAqui.Text = "Comer aqui";
            this.rdbComerAqui.UseVisualStyleBackColor = true;
            this.rdbComerAqui.CheckedChanged += new System.EventHandler(this.rdbComerAqui_CheckedChanged);
            // 
            // grbEmbalagem
            // 
            this.grbEmbalagem.Controls.Add(this.chkIsopor);
            this.grbEmbalagem.Controls.Add(this.chkAluminio);
            this.grbEmbalagem.Controls.Add(this.chkPlastica);
            this.grbEmbalagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbEmbalagem.Location = new System.Drawing.Point(315, 506);
            this.grbEmbalagem.Name = "grbEmbalagem";
            this.grbEmbalagem.Size = new System.Drawing.Size(151, 155);
            this.grbEmbalagem.TabIndex = 13;
            this.grbEmbalagem.TabStop = false;
            this.grbEmbalagem.Text = "Embalagem";
            // 
            // chkIsopor
            // 
            this.chkIsopor.AutoSize = true;
            this.chkIsopor.Location = new System.Drawing.Point(13, 87);
            this.chkIsopor.Name = "chkIsopor";
            this.chkIsopor.Size = new System.Drawing.Size(90, 29);
            this.chkIsopor.TabIndex = 0;
            this.chkIsopor.Text = "Isopor";
            this.chkIsopor.UseVisualStyleBackColor = true;
            // 
            // chkAluminio
            // 
            this.chkAluminio.AutoSize = true;
            this.chkAluminio.Location = new System.Drawing.Point(13, 58);
            this.chkAluminio.Name = "chkAluminio";
            this.chkAluminio.Size = new System.Drawing.Size(113, 29);
            this.chkAluminio.TabIndex = 0;
            this.chkAluminio.Text = "Alumínio";
            this.chkAluminio.UseVisualStyleBackColor = true;
            // 
            // chkPlastica
            // 
            this.chkPlastica.AutoSize = true;
            this.chkPlastica.Location = new System.Drawing.Point(13, 30);
            this.chkPlastica.Name = "chkPlastica";
            this.chkPlastica.Size = new System.Drawing.Size(107, 29);
            this.chkPlastica.TabIndex = 0;
            this.chkPlastica.Text = "Plástica";
            this.chkPlastica.UseVisualStyleBackColor = true;
            // 
            // grbBebidas
            // 
            this.grbBebidas.Controls.Add(this.chkVinho);
            this.grbBebidas.Controls.Add(this.chkCerveja);
            this.grbBebidas.Controls.Add(this.chkRefrigerante);
            this.grbBebidas.Controls.Add(this.chkSuco);
            this.grbBebidas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbBebidas.Location = new System.Drawing.Point(614, 506);
            this.grbBebidas.Name = "grbBebidas";
            this.grbBebidas.Size = new System.Drawing.Size(172, 155);
            this.grbBebidas.TabIndex = 14;
            this.grbBebidas.TabStop = false;
            this.grbBebidas.Text = "Bebidas";
            // 
            // chkVinho
            // 
            this.chkVinho.AutoSize = true;
            this.chkVinho.Location = new System.Drawing.Point(6, 118);
            this.chkVinho.Name = "chkVinho";
            this.chkVinho.Size = new System.Drawing.Size(86, 29);
            this.chkVinho.TabIndex = 1;
            this.chkVinho.Text = "Vinho";
            this.chkVinho.UseVisualStyleBackColor = true;
            // 
            // chkCerveja
            // 
            this.chkCerveja.AutoSize = true;
            this.chkCerveja.Location = new System.Drawing.Point(6, 87);
            this.chkCerveja.Name = "chkCerveja";
            this.chkCerveja.Size = new System.Drawing.Size(105, 29);
            this.chkCerveja.TabIndex = 1;
            this.chkCerveja.Text = "Cerveja";
            this.chkCerveja.UseVisualStyleBackColor = true;
            // 
            // chkRefrigerante
            // 
            this.chkRefrigerante.AutoSize = true;
            this.chkRefrigerante.Location = new System.Drawing.Point(6, 58);
            this.chkRefrigerante.Name = "chkRefrigerante";
            this.chkRefrigerante.Size = new System.Drawing.Size(149, 29);
            this.chkRefrigerante.TabIndex = 2;
            this.chkRefrigerante.Text = "Refrigerante";
            this.chkRefrigerante.UseVisualStyleBackColor = true;
            // 
            // chkSuco
            // 
            this.chkSuco.AutoSize = true;
            this.chkSuco.Location = new System.Drawing.Point(6, 30);
            this.chkSuco.Name = "chkSuco";
            this.chkSuco.Size = new System.Drawing.Size(80, 29);
            this.chkSuco.TabIndex = 3;
            this.chkSuco.Text = "Suco";
            this.chkSuco.UseVisualStyleBackColor = true;
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar.Location = new System.Drawing.Point(239, 708);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(298, 34);
            this.btnFinalizar.TabIndex = 9;
            this.btnFinalizar.Text = "&Finalizar montagem do prato";
            this.btnFinalizar.UseVisualStyleBackColor = true;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(275, 9);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(206, 39);
            this.lblNome.TabIndex = 15;
            this.lblNome.Text = "Restaurante";
            this.lblNome.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblTotalIngredientes
            // 
            this.lblTotalIngredientes.AutoSize = true;
            this.lblTotalIngredientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalIngredientes.Location = new System.Drawing.Point(2, 448);
            this.lblTotalIngredientes.Name = "lblTotalIngredientes";
            this.lblTotalIngredientes.Size = new System.Drawing.Size(161, 20);
            this.lblTotalIngredientes.TabIndex = 16;
            this.lblTotalIngredientes.Text = "Total de ingredientes:";
            // 
            // txtTotalIngredientes
            // 
            this.txtTotalIngredientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalIngredientes.Location = new System.Drawing.Point(239, 445);
            this.txtTotalIngredientes.Name = "txtTotalIngredientes";
            this.txtTotalIngredientes.ReadOnly = true;
            this.txtTotalIngredientes.Size = new System.Drawing.Size(70, 26);
            this.txtTotalIngredientes.TabIndex = 17;
            // 
            // lblTotalIngredientesPrato
            // 
            this.lblTotalIngredientesPrato.AutoSize = true;
            this.lblTotalIngredientesPrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalIngredientesPrato.Location = new System.Drawing.Point(479, 448);
            this.lblTotalIngredientesPrato.Name = "lblTotalIngredientesPrato";
            this.lblTotalIngredientesPrato.Size = new System.Drawing.Size(224, 20);
            this.lblTotalIngredientesPrato.TabIndex = 18;
            this.lblTotalIngredientesPrato.Text = "Total de ingredientes no prato:";
            // 
            // txtTotalIngredientesPrato
            // 
            this.txtTotalIngredientesPrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalIngredientesPrato.Location = new System.Drawing.Point(715, 445);
            this.txtTotalIngredientesPrato.Name = "txtTotalIngredientesPrato";
            this.txtTotalIngredientesPrato.ReadOnly = true;
            this.txtTotalIngredientesPrato.Size = new System.Drawing.Size(70, 26);
            this.txtTotalIngredientesPrato.TabIndex = 19;
            // 
            // frmRestaurante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 764);
            this.Controls.Add(this.txtTotalIngredientesPrato);
            this.Controls.Add(this.lblTotalIngredientesPrato);
            this.Controls.Add(this.txtTotalIngredientes);
            this.Controls.Add(this.lblTotalIngredientes);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.grbBebidas);
            this.Controls.Add(this.grbEmbalagem);
            this.Controls.Add(this.grbLocal);
            this.Controls.Add(this.lstPratoMontado);
            this.Controls.Add(this.lblPratoMontado);
            this.Controls.Add(this.btnFinalizar);
            this.Controls.Add(this.btnEspecial);
            this.Controls.Add(this.btnNovoPrato);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.lstIngredientes);
            this.Controls.Add(this.lblIngredientes);
            this.Controls.Add(this.txtNomePrato);
            this.Controls.Add(this.lblNomePrato);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.MaximizeBox = false;
            this.Name = "frmRestaurante";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Monte seu prato favorito!";
            this.Load += new System.EventHandler(this.frmRestaurante_Load);
            this.grbLocal.ResumeLayout(false);
            this.grbLocal.PerformLayout();
            this.grbEmbalagem.ResumeLayout(false);
            this.grbEmbalagem.PerformLayout();
            this.grbBebidas.ResumeLayout(false);
            this.grbBebidas.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblNomePrato;
        private System.Windows.Forms.TextBox txtNomePrato;
        private System.Windows.Forms.Label lblIngredientes;
        private System.Windows.Forms.ListBox lstIngredientes;
        private System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnNovoPrato;
        private System.Windows.Forms.Button btnEspecial;
        private System.Windows.Forms.Label lblPratoMontado;
        private System.Windows.Forms.ListBox lstPratoMontado;
        private System.Windows.Forms.GroupBox grbLocal;
        private System.Windows.Forms.RadioButton rdbViagem;
        private System.Windows.Forms.RadioButton rdbComerAqui;
        private System.Windows.Forms.GroupBox grbEmbalagem;
        private System.Windows.Forms.CheckBox chkIsopor;
        private System.Windows.Forms.CheckBox chkAluminio;
        private System.Windows.Forms.CheckBox chkPlastica;
        private System.Windows.Forms.GroupBox grbBebidas;
        private System.Windows.Forms.CheckBox chkVinho;
        private System.Windows.Forms.CheckBox chkCerveja;
        private System.Windows.Forms.CheckBox chkRefrigerante;
        private System.Windows.Forms.CheckBox chkSuco;
        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblTotalIngredientes;
        private System.Windows.Forms.TextBox txtTotalIngredientes;
        private System.Windows.Forms.Label lblTotalIngredientesPrato;
        private System.Windows.Forms.TextBox txtTotalIngredientesPrato;
    }
}

