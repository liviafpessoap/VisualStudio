﻿namespace Tabuada
{
    partial class frmTabuada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.lblVezes = new System.Windows.Forms.Label();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.lblIgual = new System.Windows.Forms.Label();
            this.btnSorteia = new System.Windows.Forms.Button();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.picRosto = new System.Windows.Forms.PictureBox();
            this.lblLabelPontosVoce = new System.Windows.Forms.Label();
            this.lblPontosVoce = new System.Windows.Forms.Label();
            this.lblvoceTem = new System.Windows.Forms.Label();
            this.lblLabelPontosComputador = new System.Windows.Forms.Label();
            this.lblPontosComputador = new System.Windows.Forms.Label();
            this.lbleuTenho = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblquantoE = new System.Windows.Forms.Label();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.lblTentativas = new System.Windows.Forms.Label();
            this.txtTentativas = new System.Windows.Forms.TextBox();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.pnlContagem = new System.Windows.Forms.Panel();
            this.lblVoceCont = new System.Windows.Forms.Label();
            this.lblVoce = new System.Windows.Forms.Label();
            this.lblComputadorCont = new System.Windows.Forms.Label();
            this.lblComputador = new System.Windows.Forms.Label();
            this.lblMensagem2 = new System.Windows.Forms.Label();
            this.pnlResultado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRosto)).BeginInit();
            this.pnlContagem.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNumero1
            // 
            this.lblNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero1.Location = new System.Drawing.Point(132, 62);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(49, 48);
            this.lblNumero1.TabIndex = 0;
            this.lblNumero1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVezes
            // 
            this.lblVezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVezes.ForeColor = System.Drawing.Color.Red;
            this.lblVezes.Location = new System.Drawing.Point(189, 71);
            this.lblVezes.Name = "lblVezes";
            this.lblVezes.Size = new System.Drawing.Size(27, 24);
            this.lblVezes.TabIndex = 1;
            this.lblVezes.Text = "X";
            this.lblVezes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumero2
            // 
            this.lblNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero2.Location = new System.Drawing.Point(224, 62);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(49, 48);
            this.lblNumero2.TabIndex = 2;
            this.lblNumero2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIgual
            // 
            this.lblIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIgual.ForeColor = System.Drawing.Color.Red;
            this.lblIgual.Location = new System.Drawing.Point(281, 71);
            this.lblIgual.Name = "lblIgual";
            this.lblIgual.Size = new System.Drawing.Size(27, 24);
            this.lblIgual.TabIndex = 3;
            this.lblIgual.Text = "=";
            this.lblIgual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSorteia
            // 
            this.btnSorteia.Location = new System.Drawing.Point(210, 123);
            this.btnSorteia.Name = "btnSorteia";
            this.btnSorteia.Size = new System.Drawing.Size(80, 40);
            this.btnSorteia.TabIndex = 6;
            this.btnSorteia.Text = "&Sorteia";
            this.btnSorteia.UseVisualStyleBackColor = true;
            this.btnSorteia.Click += new System.EventHandler(this.btnSorteia_Click);
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(112, 123);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(80, 40);
            this.btnVerifica.TabIndex = 5;
            this.btnVerifica.Text = "&Verifica";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // pnlResultado
            // 
            this.pnlResultado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlResultado.Controls.Add(this.picRosto);
            this.pnlResultado.Controls.Add(this.lblLabelPontosVoce);
            this.pnlResultado.Controls.Add(this.lblPontosVoce);
            this.pnlResultado.Controls.Add(this.lblvoceTem);
            this.pnlResultado.Controls.Add(this.lblLabelPontosComputador);
            this.pnlResultado.Controls.Add(this.lblPontosComputador);
            this.pnlResultado.Controls.Add(this.lbleuTenho);
            this.pnlResultado.Location = new System.Drawing.Point(56, 174);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(290, 89);
            this.pnlResultado.TabIndex = 7;
            // 
            // picRosto
            // 
            this.picRosto.Location = new System.Drawing.Point(172, 3);
            this.picRosto.Name = "picRosto";
            this.picRosto.Size = new System.Drawing.Size(101, 74);
            this.picRosto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRosto.TabIndex = 6;
            this.picRosto.TabStop = false;
            // 
            // lblLabelPontosVoce
            // 
            this.lblLabelPontosVoce.AutoSize = true;
            this.lblLabelPontosVoce.Location = new System.Drawing.Point(116, 38);
            this.lblLabelPontosVoce.Name = "lblLabelPontosVoce";
            this.lblLabelPontosVoce.Size = new System.Drawing.Size(39, 13);
            this.lblLabelPontosVoce.TabIndex = 5;
            this.lblLabelPontosVoce.Text = "pontos";
            // 
            // lblPontosVoce
            // 
            this.lblPontosVoce.AutoSize = true;
            this.lblPontosVoce.Location = new System.Drawing.Point(82, 38);
            this.lblPontosVoce.Name = "lblPontosVoce";
            this.lblPontosVoce.Size = new System.Drawing.Size(13, 13);
            this.lblPontosVoce.TabIndex = 4;
            this.lblPontosVoce.Text = "0";
            this.lblPontosVoce.Click += new System.EventHandler(this.lblPontosVoce_Click);
            // 
            // lblvoceTem
            // 
            this.lblvoceTem.AutoSize = true;
            this.lblvoceTem.Location = new System.Drawing.Point(28, 38);
            this.lblvoceTem.Name = "lblvoceTem";
            this.lblvoceTem.Size = new System.Drawing.Size(52, 13);
            this.lblvoceTem.TabIndex = 3;
            this.lblvoceTem.Text = "Você tem";
            // 
            // lblLabelPontosComputador
            // 
            this.lblLabelPontosComputador.AutoSize = true;
            this.lblLabelPontosComputador.Location = new System.Drawing.Point(116, 14);
            this.lblLabelPontosComputador.Name = "lblLabelPontosComputador";
            this.lblLabelPontosComputador.Size = new System.Drawing.Size(39, 13);
            this.lblLabelPontosComputador.TabIndex = 2;
            this.lblLabelPontosComputador.Text = "pontos";
            // 
            // lblPontosComputador
            // 
            this.lblPontosComputador.AutoSize = true;
            this.lblPontosComputador.Location = new System.Drawing.Point(82, 14);
            this.lblPontosComputador.Name = "lblPontosComputador";
            this.lblPontosComputador.Size = new System.Drawing.Size(13, 13);
            this.lblPontosComputador.TabIndex = 1;
            this.lblPontosComputador.Text = "0";
            this.lblPontosComputador.Click += new System.EventHandler(this.lblPontosComputador_Click);
            // 
            // lbleuTenho
            // 
            this.lbleuTenho.AutoSize = true;
            this.lbleuTenho.Location = new System.Drawing.Point(28, 14);
            this.lbleuTenho.Name = "lbleuTenho";
            this.lbleuTenho.Size = new System.Drawing.Size(50, 13);
            this.lbleuTenho.TabIndex = 0;
            this.lbleuTenho.Text = "Eu tenho";
            // 
            // txtResultado
            // 
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(327, 67);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(49, 40);
            this.txtResultado.TabIndex = 4;
            this.txtResultado.Enter += new System.EventHandler(this.txtResultado_Enter);
            // 
            // lblquantoE
            // 
            this.lblquantoE.AutoSize = true;
            this.lblquantoE.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquantoE.Location = new System.Drawing.Point(12, 74);
            this.lblquantoE.Name = "lblquantoE";
            this.lblquantoE.Size = new System.Drawing.Size(112, 25);
            this.lblquantoE.TabIndex = 8;
            this.lblquantoE.Text = "Quanto é?";
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensagem.ForeColor = System.Drawing.Color.Blue;
            this.lblMensagem.Location = new System.Drawing.Point(12, 348);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(78, 16);
            this.lblMensagem.TabIndex = 9;
            this.lblMensagem.Text = "Mensagem:";
            // 
            // lblTentativas
            // 
            this.lblTentativas.AutoSize = true;
            this.lblTentativas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTentativas.Location = new System.Drawing.Point(11, 21);
            this.lblTentativas.Name = "lblTentativas";
            this.lblTentativas.Size = new System.Drawing.Size(232, 24);
            this.lblTentativas.TabIndex = 10;
            this.lblTentativas.Text = "Quantas tentativas deseja?";
            this.lblTentativas.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtTentativas
            // 
            this.txtTentativas.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTentativas.Location = new System.Drawing.Point(259, 12);
            this.txtTentativas.Name = "txtTentativas";
            this.txtTentativas.Size = new System.Drawing.Size(49, 40);
            this.txtTentativas.TabIndex = 11;
            // 
            // btnIniciar
            // 
            this.btnIniciar.Location = new System.Drawing.Point(327, 12);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(51, 40);
            this.btnIniciar.TabIndex = 12;
            this.btnIniciar.Text = "&Iniciar";
            this.btnIniciar.UseVisualStyleBackColor = true;
            // 
            // pnlContagem
            // 
            this.pnlContagem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlContagem.Controls.Add(this.lblVoceCont);
            this.pnlContagem.Controls.Add(this.lblVoce);
            this.pnlContagem.Controls.Add(this.lblComputadorCont);
            this.pnlContagem.Controls.Add(this.lblComputador);
            this.pnlContagem.Location = new System.Drawing.Point(56, 269);
            this.pnlContagem.Name = "pnlContagem";
            this.pnlContagem.Size = new System.Drawing.Size(290, 69);
            this.pnlContagem.TabIndex = 8;
            // 
            // lblVoceCont
            // 
            this.lblVoceCont.AutoSize = true;
            this.lblVoceCont.Location = new System.Drawing.Point(98, 38);
            this.lblVoceCont.Name = "lblVoceCont";
            this.lblVoceCont.Size = new System.Drawing.Size(13, 13);
            this.lblVoceCont.TabIndex = 4;
            this.lblVoceCont.Text = "0";
            // 
            // lblVoce
            // 
            this.lblVoce.AutoSize = true;
            this.lblVoce.Location = new System.Drawing.Point(28, 38);
            this.lblVoce.Name = "lblVoce";
            this.lblVoce.Size = new System.Drawing.Size(32, 13);
            this.lblVoce.TabIndex = 3;
            this.lblVoce.Text = "Você";
            // 
            // lblComputadorCont
            // 
            this.lblComputadorCont.AutoSize = true;
            this.lblComputadorCont.Location = new System.Drawing.Point(98, 14);
            this.lblComputadorCont.Name = "lblComputadorCont";
            this.lblComputadorCont.Size = new System.Drawing.Size(13, 13);
            this.lblComputadorCont.TabIndex = 1;
            this.lblComputadorCont.Text = "0";
            // 
            // lblComputador
            // 
            this.lblComputador.AutoSize = true;
            this.lblComputador.Location = new System.Drawing.Point(28, 14);
            this.lblComputador.Name = "lblComputador";
            this.lblComputador.Size = new System.Drawing.Size(64, 13);
            this.lblComputador.TabIndex = 0;
            this.lblComputador.Text = "Computador";
            // 
            // lblMensagem2
            // 
            this.lblMensagem2.AutoSize = true;
            this.lblMensagem2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensagem2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMensagem2.Location = new System.Drawing.Point(12, 370);
            this.lblMensagem2.Name = "lblMensagem2";
            this.lblMensagem2.Size = new System.Drawing.Size(73, 16);
            this.lblMensagem2.TabIndex = 14;
            this.lblMensagem2.Text = "Tentativas:";
            // 
            // frmTabuada
            // 
            this.AcceptButton = this.btnVerifica;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(405, 397);
            this.Controls.Add(this.lblMensagem2);
            this.Controls.Add(this.pnlContagem);
            this.Controls.Add(this.btnIniciar);
            this.Controls.Add(this.txtTentativas);
            this.Controls.Add(this.lblTentativas);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.lblquantoE);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.pnlResultado);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.btnSorteia);
            this.Controls.Add(this.lblIgual);
            this.Controls.Add(this.lblNumero2);
            this.Controls.Add(this.lblVezes);
            this.Controls.Add(this.lblNumero1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmTabuada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabuada";
            this.Load += new System.EventHandler(this.frmTabuada_Load);
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRosto)).EndInit();
            this.pnlContagem.ResumeLayout(false);
            this.pnlContagem.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label lblVezes;
        private System.Windows.Forms.Label lblNumero2;
        private System.Windows.Forms.Label lblIgual;
        private System.Windows.Forms.Button btnSorteia;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Label lbleuTenho;
        private System.Windows.Forms.Label lblLabelPontosVoce;
        private System.Windows.Forms.Label lblPontosVoce;
        private System.Windows.Forms.Label lblvoceTem;
        private System.Windows.Forms.Label lblLabelPontosComputador;
        private System.Windows.Forms.Label lblPontosComputador;
        private System.Windows.Forms.PictureBox picRosto;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblquantoE;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Label lblTentativas;
        private System.Windows.Forms.TextBox txtTentativas;
        private System.Windows.Forms.Button btnIniciar;
        private System.Windows.Forms.Panel pnlContagem;
        private System.Windows.Forms.Label lblVoceCont;
        private System.Windows.Forms.Label lblVoce;
        private System.Windows.Forms.Label lblComputadorCont;
        private System.Windows.Forms.Label lblComputador;
        private System.Windows.Forms.Label lblMensagem2;
    }
}

