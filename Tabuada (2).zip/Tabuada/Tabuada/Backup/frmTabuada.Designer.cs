﻿namespace Tabuada
{
    partial class frmTabuada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.lblVezes = new System.Windows.Forms.Label();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.lblIgual = new System.Windows.Forms.Label();
            this.btnSorteia = new System.Windows.Forms.Button();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.lbleuTenho = new System.Windows.Forms.Label();
            this.lblPontosComputador = new System.Windows.Forms.Label();
            this.lblLabelPontosComputador = new System.Windows.Forms.Label();
            this.lblLabelPontosVoce = new System.Windows.Forms.Label();
            this.lblPontosVoce = new System.Windows.Forms.Label();
            this.lblvoceTem = new System.Windows.Forms.Label();
            this.picRosto = new System.Windows.Forms.PictureBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.pnlResultado.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRosto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNumero1
            // 
            this.lblNumero1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero1.Location = new System.Drawing.Point(19, 17);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(49, 48);
            this.lblNumero1.TabIndex = 0;
            this.lblNumero1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVezes
            // 
            this.lblVezes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVezes.ForeColor = System.Drawing.Color.Red;
            this.lblVezes.Location = new System.Drawing.Point(76, 26);
            this.lblVezes.Name = "lblVezes";
            this.lblVezes.Size = new System.Drawing.Size(27, 24);
            this.lblVezes.TabIndex = 1;
            this.lblVezes.Text = "X";
            this.lblVezes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNumero2
            // 
            this.lblNumero2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero2.Location = new System.Drawing.Point(111, 17);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(49, 48);
            this.lblNumero2.TabIndex = 2;
            this.lblNumero2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIgual
            // 
            this.lblIgual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIgual.ForeColor = System.Drawing.Color.Red;
            this.lblIgual.Location = new System.Drawing.Point(168, 26);
            this.lblIgual.Name = "lblIgual";
            this.lblIgual.Size = new System.Drawing.Size(27, 24);
            this.lblIgual.TabIndex = 3;
            this.lblIgual.Text = "=";
            this.lblIgual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSorteia
            // 
            this.btnSorteia.Location = new System.Drawing.Point(147, 84);
            this.btnSorteia.Name = "btnSorteia";
            this.btnSorteia.Size = new System.Drawing.Size(80, 40);
            this.btnSorteia.TabIndex = 6;
            this.btnSorteia.Text = "&Sorteia";
            this.btnSorteia.UseVisualStyleBackColor = true;
            this.btnSorteia.Click += new System.EventHandler(this.btnSorteia_Click);
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(49, 84);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(80, 40);
            this.btnVerifica.TabIndex = 5;
            this.btnVerifica.Text = "&Verifica";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // pnlResultado
            // 
            this.pnlResultado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlResultado.Controls.Add(this.picRosto);
            this.pnlResultado.Controls.Add(this.lblLabelPontosVoce);
            this.pnlResultado.Controls.Add(this.lblPontosVoce);
            this.pnlResultado.Controls.Add(this.lblvoceTem);
            this.pnlResultado.Controls.Add(this.lblLabelPontosComputador);
            this.pnlResultado.Controls.Add(this.lblPontosComputador);
            this.pnlResultado.Controls.Add(this.lbleuTenho);
            this.pnlResultado.Location = new System.Drawing.Point(16, 130);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(253, 71);
            this.pnlResultado.TabIndex = 7;
            // 
            // lbleuTenho
            // 
            this.lbleuTenho.AutoSize = true;
            this.lbleuTenho.Location = new System.Drawing.Point(28, 14);
            this.lbleuTenho.Name = "lbleuTenho";
            this.lbleuTenho.Size = new System.Drawing.Size(50, 13);
            this.lbleuTenho.TabIndex = 0;
            this.lbleuTenho.Text = "Eu tenho";
            // 
            // lblPontosComputador
            // 
            this.lblPontosComputador.AutoSize = true;
            this.lblPontosComputador.Location = new System.Drawing.Point(82, 14);
            this.lblPontosComputador.Name = "lblPontosComputador";
            this.lblPontosComputador.Size = new System.Drawing.Size(13, 13);
            this.lblPontosComputador.TabIndex = 1;
            this.lblPontosComputador.Text = "0";
            // 
            // lblLabelPontosComputador
            // 
            this.lblLabelPontosComputador.AutoSize = true;
            this.lblLabelPontosComputador.Location = new System.Drawing.Point(116, 14);
            this.lblLabelPontosComputador.Name = "lblLabelPontosComputador";
            this.lblLabelPontosComputador.Size = new System.Drawing.Size(39, 13);
            this.lblLabelPontosComputador.TabIndex = 2;
            this.lblLabelPontosComputador.Text = "pontos";
            // 
            // lblLabelPontosVoce
            // 
            this.lblLabelPontosVoce.AutoSize = true;
            this.lblLabelPontosVoce.Location = new System.Drawing.Point(116, 38);
            this.lblLabelPontosVoce.Name = "lblLabelPontosVoce";
            this.lblLabelPontosVoce.Size = new System.Drawing.Size(39, 13);
            this.lblLabelPontosVoce.TabIndex = 5;
            this.lblLabelPontosVoce.Text = "pontos";
            // 
            // lblPontosVoce
            // 
            this.lblPontosVoce.AutoSize = true;
            this.lblPontosVoce.Location = new System.Drawing.Point(82, 38);
            this.lblPontosVoce.Name = "lblPontosVoce";
            this.lblPontosVoce.Size = new System.Drawing.Size(13, 13);
            this.lblPontosVoce.TabIndex = 4;
            this.lblPontosVoce.Text = "0";
            // 
            // lblvoceTem
            // 
            this.lblvoceTem.AutoSize = true;
            this.lblvoceTem.Location = new System.Drawing.Point(28, 38);
            this.lblvoceTem.Name = "lblvoceTem";
            this.lblvoceTem.Size = new System.Drawing.Size(52, 13);
            this.lblvoceTem.TabIndex = 3;
            this.lblvoceTem.Text = "Você tem";
            // 
            // picRosto
            // 
            this.picRosto.Location = new System.Drawing.Point(170, 15);
            this.picRosto.Name = "picRosto";
            this.picRosto.Size = new System.Drawing.Size(39, 35);
            this.picRosto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRosto.TabIndex = 6;
            this.picRosto.TabStop = false;
            // 
            // txtResultado
            // 
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(203, 23);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(49, 40);
            this.txtResultado.TabIndex = 4;
            // 
            // frmTabuada
            // 
            this.AcceptButton = this.btnVerifica;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 208);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.pnlResultado);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.btnSorteia);
            this.Controls.Add(this.lblIgual);
            this.Controls.Add(this.lblNumero2);
            this.Controls.Add(this.lblVezes);
            this.Controls.Add(this.lblNumero1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmTabuada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tabuada";
            this.Load += new System.EventHandler(this.frmTabuada_Load);
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRosto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label lblVezes;
        private System.Windows.Forms.Label lblNumero2;
        private System.Windows.Forms.Label lblIgual;
        private System.Windows.Forms.Button btnSorteia;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Label lbleuTenho;
        private System.Windows.Forms.Label lblLabelPontosVoce;
        private System.Windows.Forms.Label lblPontosVoce;
        private System.Windows.Forms.Label lblvoceTem;
        private System.Windows.Forms.Label lblLabelPontosComputador;
        private System.Windows.Forms.Label lblPontosComputador;
        private System.Windows.Forms.PictureBox picRosto;
        private System.Windows.Forms.TextBox txtResultado;
    }
}

