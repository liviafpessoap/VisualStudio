﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tabuada
{
    public partial class frmTabuada : Form
    {
        int primeiro, segundo, sorteio = 0;
        int pontosComputador, pontosVoce;
        public frmTabuada()
        {
            InitializeComponent();
        }

        private void frmTabuada_Load(object sender, EventArgs e)
        {
            btnSorteia.Enabled = false;
            sorteia(); // Chama o método que sorteia o primeiro e o segundo número da tabuada
        }

        private void sorteia()
        {
            Random Randomico = new Random();
            primeiro = Randomico.Next(10) + 1; // Sorteia o primeiro número entre 1 e 10
            segundo = Randomico.Next(10) + 1; // Sorteia o segundo número entre 1 e 10

            lblNumero1.Text = primeiro.ToString(); // Exibe o primeiro número
            lblNumero2.Text = segundo.ToString(); // Exibe o segundo número
            // O método ToString é necessário pois a variável é inteira e o label é string
        }

        private void btnSorteia_Click(object sender, EventArgs e)
        {
            btnVerifica.Enabled = true;
            sorteia();
            txtResultado.Text = ""; // Apaga o resultado digitado
            txtResultado.Focus(); // Coloca o foco (cursor) nesta caixa
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            if ((primeiro * segundo) == int.Parse(txtResultado.Text))
            {
                pontosVoce += 1;
            }
            else
            {
                pontosComputador += 1;
            }

            // Exibe os pontos
            lblPontosComputador.Text = pontosComputador.ToString();
            lblPontosVoce.Text = pontosVoce.ToString();

            btnVerifica.Enabled = false; // Desabilita este botão

            btnSorteia.Enabled = true; // Habilita este botãos            
        }
    }
}
