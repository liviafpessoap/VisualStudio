﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Produtos
{
    public partial class frmProdutos : Form
    {
        public frmProdutos()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tem certeza?","Saindo do aplicativo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            cmbProduto.SelectedIndex = -1;  // não deixa nenhum item selecionado (cmbProduto.Text = "";)
            txtPrecoUnitario.Clear();  // limpa o conteudo do textbox
            txtQuantidade.Clear();
            txtExibir.Clear();
            cmbProduto.Focus();  // envia (coloca) o foco (cursor) na caixa especificada
        }

        private void btnConfirma_Click(object sender, EventArgs e)
        {
            double PrecoUnitario = Convert.ToDouble(txtPrecoUnitario.Text);
            double Quantidade = Convert.ToDouble(txtQuantidade.Text);

            double resultado = PrecoUnitario * Quantidade;

            txtExibir.Text = resultado.ToString();

        }
    }
}
