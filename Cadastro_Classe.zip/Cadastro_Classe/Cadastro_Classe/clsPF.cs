﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Classe
{
    internal class clsPF
    {
        private string cpf;
        private string rg;

        public string CPF
        {
            get { return cpf; }
            set { cpf = value; }
        }

        public string RG
        {
            get { return rg; }
            set { rg = value; }
        }
    }
}
