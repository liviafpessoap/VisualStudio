﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Classe
{
    internal class clsPJ
    {
        private string cnpj;
        private string inscricaoEstadual;

        public string CNPJ 
        {
            get { return cnpj; }
            set { cnpj = value; }
        }

        public string InscricaoEstadual 
        { 
            get { return inscricaoEstadual; }
            set { inscricaoEstadual = value; }
        }
    }
}
