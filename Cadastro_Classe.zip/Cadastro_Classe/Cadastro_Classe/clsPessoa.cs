﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Classe
{
    internal class clsPessoa
    {
        private int codigo;
        private string nome;
        private string endereço;
        private string cidade;
        private string uf;
        private string email;
        private DateTime dataCadastro;


        // Propriedades públicas para ter acesso aos atributos acima
        public int Codigo
        { 
            get { return codigo; }
            set { codigo = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Endereço
        {
            get { return endereço; }
            set { endereço = value; }
        }

        public string Cidade
        {
            get { return cidade; }
            set { cidade = value; }
        }

        public string UF
        {
            get { return uf; }
            set { uf = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public DateTime DataCadastro
        {
            get { return dataCadastro; }
            set { dataCadastro = value; }
        }

    }
} 
