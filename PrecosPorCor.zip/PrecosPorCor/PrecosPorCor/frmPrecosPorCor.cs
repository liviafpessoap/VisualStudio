﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrecosPorCor
{
    public partial class frmPrecosPorCor : Form
    {
        public frmPrecosPorCor()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            string mensagem = "O preço referente a cor ";
            string cor = "";
            cor = txtCor.Text;

            if (cor == "verde")
            {
                mensagem = string.Format("{0}{1} é 10,00", mensagem, cor);
                lblMensagem.ForeColor = Color.Green;
                lblMensagem.BackColor = Color.White;
            }

            else if (cor == "azul")
            {
                mensagem = string.Format("{0}{1} é 20,00", mensagem, cor);
                lblMensagem.ForeColor = Color.Blue;
                lblMensagem.BackColor = Color.White;
            }

            else if (cor == "amarelo")
            {
                mensagem = string.Format("{0}{1} é 30,00", mensagem, cor);
                lblMensagem.ForeColor = Color.Yellow;
                lblMensagem.BackColor = Color.Gray;
            }

            else if (cor == "vermelho")
            {
                mensagem = string.Format("{0}{1} é 40,00", mensagem, cor);
                lblMensagem.ForeColor = Color.Red;
                lblMensagem.BackColor = Color.White;
            }

            else
            {
                mensagem = "Esta cor não está disponível";
                lblMensagem.ForeColor = Color.Gray;
            }

            lblMensagem.Text = mensagem;
            txtCor.Clear();
        }
    }
}
