﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salário
{
    public partial class frmSalario : Form
    {
        public frmSalario()
        {
            InitializeComponent();
        }

        private void frmSalario_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salario = 0, percentual = 0, valoraumento = 0, salarioaumento = 0, desconto8 = 0, salariodesconto = 0;

            salario = Convert.ToDouble(txtSalarioAtual.Text);
            percentual = Convert.ToDouble(txtPercentual.Text);
            desconto8 = Convert.ToDouble(txtDesconto8.Text);
            salariodesconto = Convert.ToDouble(txtSalarioDesconto.Text);

            valoraumento = (salario * percentual) / 100;
            salarioaumento = salario + valoraumento;
            desconto8 = salarioaumento * 0.08;
            salariodesconto = salarioaumento - desconto8;

        }
    }
}
