﻿namespace Salário
{
    partial class frmSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbDados = new System.Windows.Forms.GroupBox();
            this.txtPercentual = new System.Windows.Forms.TextBox();
            this.txtSalarioAtual = new System.Windows.Forms.TextBox();
            this.lblSalarioAtual = new System.Windows.Forms.Label();
            this.lblPorcentagem = new System.Windows.Forms.Label();
            this.gbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.gbResultado = new System.Windows.Forms.GroupBox();
            this.txtSalarioDesconto = new System.Windows.Forms.TextBox();
            this.txtDesconto8 = new System.Windows.Forms.TextBox();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.txtSalarioAumento = new System.Windows.Forms.TextBox();
            this.txtValorAumento = new System.Windows.Forms.TextBox();
            this.lblSalarioDesconto = new System.Windows.Forms.Label();
            this.lblValorAumento = new System.Windows.Forms.Label();
            this.lblSalarioAumento = new System.Windows.Forms.Label();
            this.lblDesconto8 = new System.Windows.Forms.Label();
            this.lblDesconto = new System.Windows.Forms.Label();
            this.gbDados.SuspendLayout();
            this.gbOpcoes.SuspendLayout();
            this.gbResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbDados
            // 
            this.gbDados.Controls.Add(this.txtPercentual);
            this.gbDados.Controls.Add(this.txtSalarioAtual);
            this.gbDados.Controls.Add(this.lblSalarioAtual);
            this.gbDados.Controls.Add(this.lblPorcentagem);
            this.gbDados.Location = new System.Drawing.Point(12, 12);
            this.gbDados.Name = "gbDados";
            this.gbDados.Size = new System.Drawing.Size(200, 72);
            this.gbDados.TabIndex = 0;
            this.gbDados.TabStop = false;
            this.gbDados.Text = "Dados";
            // 
            // txtPercentual
            // 
            this.txtPercentual.Location = new System.Drawing.Point(90, 39);
            this.txtPercentual.Name = "txtPercentual";
            this.txtPercentual.Size = new System.Drawing.Size(66, 20);
            this.txtPercentual.TabIndex = 3;
            // 
            // txtSalarioAtual
            // 
            this.txtSalarioAtual.Location = new System.Drawing.Point(90, 18);
            this.txtSalarioAtual.Name = "txtSalarioAtual";
            this.txtSalarioAtual.Size = new System.Drawing.Size(66, 20);
            this.txtSalarioAtual.TabIndex = 2;
            // 
            // lblSalarioAtual
            // 
            this.lblSalarioAtual.AutoSize = true;
            this.lblSalarioAtual.Location = new System.Drawing.Point(16, 21);
            this.lblSalarioAtual.Name = "lblSalarioAtual";
            this.lblSalarioAtual.Size = new System.Drawing.Size(68, 13);
            this.lblSalarioAtual.TabIndex = 1;
            this.lblSalarioAtual.Text = "Salário atual:";
            // 
            // lblPorcentagem
            // 
            this.lblPorcentagem.AutoSize = true;
            this.lblPorcentagem.Location = new System.Drawing.Point(7, 42);
            this.lblPorcentagem.Name = "lblPorcentagem";
            this.lblPorcentagem.Size = new System.Drawing.Size(77, 13);
            this.lblPorcentagem.TabIndex = 0;
            this.lblPorcentagem.Text = "% de aumento:";
            // 
            // gbOpcoes
            // 
            this.gbOpcoes.Controls.Add(this.btnSair);
            this.gbOpcoes.Controls.Add(this.btnCalcular);
            this.gbOpcoes.Location = new System.Drawing.Point(12, 90);
            this.gbOpcoes.Name = "gbOpcoes";
            this.gbOpcoes.Size = new System.Drawing.Size(209, 100);
            this.gbOpcoes.TabIndex = 1;
            this.gbOpcoes.TabStop = false;
            this.gbOpcoes.Text = "Opções";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(124, 35);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(72, 39);
            this.btnSair.TabIndex = 0;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(12, 35);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(72, 39);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // gbResultado
            // 
            this.gbResultado.Controls.Add(this.txtSalarioDesconto);
            this.gbResultado.Controls.Add(this.txtDesconto8);
            this.gbResultado.Controls.Add(this.txtDesconto);
            this.gbResultado.Controls.Add(this.txtSalarioAumento);
            this.gbResultado.Controls.Add(this.txtValorAumento);
            this.gbResultado.Controls.Add(this.lblSalarioDesconto);
            this.gbResultado.Controls.Add(this.lblValorAumento);
            this.gbResultado.Controls.Add(this.lblSalarioAumento);
            this.gbResultado.Controls.Add(this.lblDesconto8);
            this.gbResultado.Controls.Add(this.lblDesconto);
            this.gbResultado.Location = new System.Drawing.Point(12, 196);
            this.gbResultado.Name = "gbResultado";
            this.gbResultado.Size = new System.Drawing.Size(209, 139);
            this.gbResultado.TabIndex = 2;
            this.gbResultado.TabStop = false;
            this.gbResultado.Text = "Resultado";
            // 
            // txtSalarioDesconto
            // 
            this.txtSalarioDesconto.Location = new System.Drawing.Point(124, 107);
            this.txtSalarioDesconto.Name = "txtSalarioDesconto";
            this.txtSalarioDesconto.Size = new System.Drawing.Size(66, 20);
            this.txtSalarioDesconto.TabIndex = 3;
            // 
            // txtDesconto8
            // 
            this.txtDesconto8.Location = new System.Drawing.Point(124, 85);
            this.txtDesconto8.Name = "txtDesconto8";
            this.txtDesconto8.Size = new System.Drawing.Size(66, 20);
            this.txtDesconto8.TabIndex = 3;
            // 
            // txtDesconto
            // 
            this.txtDesconto.Location = new System.Drawing.Point(124, 64);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(66, 20);
            this.txtDesconto.TabIndex = 3;
            // 
            // txtSalarioAumento
            // 
            this.txtSalarioAumento.Location = new System.Drawing.Point(124, 43);
            this.txtSalarioAumento.Name = "txtSalarioAumento";
            this.txtSalarioAumento.Size = new System.Drawing.Size(66, 20);
            this.txtSalarioAumento.TabIndex = 3;
            // 
            // txtValorAumento
            // 
            this.txtValorAumento.Location = new System.Drawing.Point(124, 22);
            this.txtValorAumento.Name = "txtValorAumento";
            this.txtValorAumento.Size = new System.Drawing.Size(66, 20);
            this.txtValorAumento.TabIndex = 3;
            // 
            // lblSalarioDesconto
            // 
            this.lblSalarioDesconto.AutoSize = true;
            this.lblSalarioDesconto.Location = new System.Drawing.Point(6, 110);
            this.lblSalarioDesconto.Name = "lblSalarioDesconto";
            this.lblSalarioDesconto.Size = new System.Drawing.Size(112, 13);
            this.lblSalarioDesconto.TabIndex = 0;
            this.lblSalarioDesconto.Text = "Salário com desconto:";
            // 
            // lblValorAumento
            // 
            this.lblValorAumento.AutoSize = true;
            this.lblValorAumento.Location = new System.Drawing.Point(25, 25);
            this.lblValorAumento.Name = "lblValorAumento";
            this.lblValorAumento.Size = new System.Drawing.Size(93, 13);
            this.lblValorAumento.TabIndex = 0;
            this.lblValorAumento.Text = "Valor do aumento:";
            this.lblValorAumento.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSalarioAumento
            // 
            this.lblSalarioAumento.AutoSize = true;
            this.lblSalarioAumento.Location = new System.Drawing.Point(9, 46);
            this.lblSalarioAumento.Name = "lblSalarioAumento";
            this.lblSalarioAumento.Size = new System.Drawing.Size(109, 13);
            this.lblSalarioAumento.TabIndex = 0;
            this.lblSalarioAumento.Text = "Salário com aumento:";
            // 
            // lblDesconto8
            // 
            this.lblDesconto8.AutoSize = true;
            this.lblDesconto8.Location = new System.Drawing.Point(20, 88);
            this.lblDesconto8.Name = "lblDesconto8";
            this.lblDesconto8.Size = new System.Drawing.Size(98, 13);
            this.lblDesconto8.TabIndex = 0;
            this.lblDesconto8.Text = "Valor desconto 8%:";
            // 
            // lblDesconto
            // 
            this.lblDesconto.AutoSize = true;
            this.lblDesconto.Location = new System.Drawing.Point(47, 67);
            this.lblDesconto.Name = "lblDesconto";
            this.lblDesconto.Size = new System.Drawing.Size(71, 13);
            this.lblDesconto.TabIndex = 0;
            this.lblDesconto.Text = "Desconto de:";
            // 
            // frmSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 348);
            this.Controls.Add(this.gbResultado);
            this.Controls.Add(this.gbOpcoes);
            this.Controls.Add(this.gbDados);
            this.Name = "frmSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cálculo de salário";
            this.Load += new System.EventHandler(this.frmSalario_Load);
            this.gbDados.ResumeLayout(false);
            this.gbDados.PerformLayout();
            this.gbOpcoes.ResumeLayout(false);
            this.gbResultado.ResumeLayout(false);
            this.gbResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbDados;
        private System.Windows.Forms.TextBox txtPercentual;
        private System.Windows.Forms.TextBox txtSalarioAtual;
        private System.Windows.Forms.Label lblSalarioAtual;
        private System.Windows.Forms.Label lblPorcentagem;
        private System.Windows.Forms.GroupBox gbOpcoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.GroupBox gbResultado;
        private System.Windows.Forms.Label lblSalarioDesconto;
        private System.Windows.Forms.Label lblValorAumento;
        private System.Windows.Forms.Label lblSalarioAumento;
        private System.Windows.Forms.Label lblDesconto8;
        private System.Windows.Forms.Label lblDesconto;
        private System.Windows.Forms.TextBox txtSalarioDesconto;
        private System.Windows.Forms.TextBox txtDesconto8;
        private System.Windows.Forms.TextBox txtDesconto;
        private System.Windows.Forms.TextBox txtSalarioAumento;
        private System.Windows.Forms.TextBox txtValorAumento;
    }
}

