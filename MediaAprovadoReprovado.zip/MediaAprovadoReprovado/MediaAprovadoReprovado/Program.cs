﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaAprovadoReprovado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nProgramação Orientada a Objetos");
            Console.Write("\nMédia de 3 notas");
            Console.Write("\n");

            // Instanciando a classe clsMedia

            clsMedia objMedia = new clsMedia();

            Console.Write("Informe a nota 1: ");
            double nota1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Informe a nota 2: ");
            double nota2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Informe a nota 3: ");
            double nota3 = Convert.ToDouble(Console.ReadLine());

            double media = objMedia.CalcularMedia(nota1, nota2, nota3);
            Console.Write("\nA média é: " + media);

            Console.ReadKey();
        }
    }
}
