﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseDadosPessoais
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Classe Dados Pessoais");
            DadosPessoais objDados = new DadosPessoais();
            objDados.Nome = "Liverton";
            objDados.Cidade = "Bebedouro";
            objDados.Email = "liverton@gmail.com";
            objDados.Cpf = "101.010.101-01";
            objDados.Idade = 23;

            Console.WriteLine(objDados.Nome);
            Console.WriteLine(objDados.Cidade);
            Console.WriteLine(objDados.Email);
            Console.WriteLine(objDados.Cpf);
            Console.WriteLine(objDados.Idade);
            Console.ReadKey();
        }

        public class DadosPessoais
        {
            // Definindo os atributos
            private string nome;
            private string cidade;
            private string email;
            private string cpf;
            private int idade;

            public string Nome
            {
                get { return Nome; }
                set { Nome = value; }
            }

            public string Cidade
            {
                get { return cidade; }
                set { cidade = value; }
            }

            public string Email
            {
                get { return email; }
                set { Email = value; }
            }

            public string Cpf
            {
                get { return cpf; }
                set { Cpf = value; }
            }

            public int Idade
            {
                get { return idade; }
                set { Idade = value; }
            }

        }
    }
}
