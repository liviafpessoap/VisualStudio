﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_DLL
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void mnuItemSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuItemCliente_Click(object sender, EventArgs e)
        {
            frmCadastro form = new frmCadastro();
            form.ShowDialog();
        }

        private void mnuItemFornecedor_Click(object sender, EventArgs e)
        {
            frmFornecedor form = new frmFornecedor();
            form.ShowDialog();
        }
    }
}
