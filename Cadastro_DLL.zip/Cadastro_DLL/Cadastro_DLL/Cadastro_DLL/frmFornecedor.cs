﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_DLL
{
    public partial class frmFornecedor : Form
    {
        public frmFornecedor()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            btnSalvar.Enabled = false;
            btnNovo.Enabled = true;

            txtCodigo.Clear();
            txtRazaoSocial.Clear();
            txtNomeFantasia.Clear();
            txtCidade.Clear();
            txtEmail.Clear();
            mskCNPJ.Clear();
            mskInscricaoEstadual.Clear();

            gpbDados.Enabled = false;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            gpbDados.Enabled = true;
            btnNovo.Enabled = false;
            btnSalvar.Enabled = true;
            txtCodigo.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Dispose(); // Fecha o formulário e renova a memória
        }
    }
}
