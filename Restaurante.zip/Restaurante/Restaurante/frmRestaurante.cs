﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restaurante
{
    public partial class frmRestaurante : Form
    {
        public frmRestaurante()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (lstIngredientes.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um ingrediente.");
                return;
            }
            if(lstPratoMontado.FindString(lstIngredientes.SelectedItem.ToString()) == -1)
            // "findstring" verifica se o item existe dentro do listbox
            // == pergunta se é verdadeiro, = afirma que é verdadeiro
            // senão existir ( == -1 ) ele será adicionado na linha abaixo
            {
                lstPratoMontado.Items.Add(lstIngredientes.SelectedItem);
            }
            else
            {
                MessageBox.Show("Este ingrediente já foi aicionado.");
            }

            txtTotalIngredientesPrato.Text = lstPratoMontado.Items.Count.ToString();
        }

        private void frmRestaurante_Load(object sender, EventArgs e)
        {
            lstIngredientes.Items.Add("Arroz branco");
            lstIngredientes.Items.Add("Arroz temperado");
            lstIngredientes.Items.Add("Feijão");
            lstIngredientes.Items.Add("Batata frita");
            lstIngredientes.Items.Add("Mandioca frita");
            lstIngredientes.Items.Add("Ovo frito");
            lstIngredientes.Items.Add("Bife acebolado");
            lstIngredientes.Items.Add("Coxa de frango");
            lstIngredientes.Items.Add("Frango a parmegiana");
            lstIngredientes.Items.Add("Carne de panela com batata");
            lstIngredientes.Items.Add("Salada de alface");
            lstIngredientes.Items.Add("Salada de rúcula");
            lstIngredientes.Items.Add("Macarrão a bolognesa");
            lstIngredientes.Items.Add("Salada de macarrão");

            txtTotalIngredientes.Text = lstIngredientes.Items.Count.ToString(); // exibe a quantidade de ingredientes

            grbEmbalagem.Enabled = false; // desabilita o ingrediente de embalagem

            rdbComerAqui.Checked = true; // deixa o radiobutton do "Comer aqui" selecionado
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void rdbComerAqui_CheckedChanged(object sender, EventArgs e)
        {
            grbEmbalagem.Enabled = false; // desabilita a seleção
            chkAluminio.Checked = false; // retira a seleção
            chkIsopor.Checked = false;
            chkPlastica.Checked = false;
        }

        private void rdbViagem_CheckedChanged(object sender, EventArgs e)
        {
            grbEmbalagem.Enabled = true;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            // se não tiver nenhum ingrediente adicionado, não permite a exclusão
            if (lstPratoMontado.Items.Count == 0)
            {
                MessageBox.Show("Não há nenhum item selecionado.");
            }
            
            // se nenhum ingrediente selecionado em lstPratoMontado, não permite a exclusão
            if(lstPratoMontado.SelectedIndex != -1) // ! significa não, logo, se não for igual a -1
            {
                // exlui os ingredientes selecionados da lstPratoMontado
                lstPratoMontado.Items.RemoveAt(lstPratoMontado.SelectedIndex);
            }

            else
            {
                MessageBox.Show("Selecione um item para excluir.");
            }
        }

        private void btnNovoPrato_Click(object sender, EventArgs e)
        {
            Application.Restart(); // reinicia o software 

            // txtNomePrato.Clear();
            // lstPratoMontado.Clear();
            // rdbComerAqui.Checked = true;
            // txtIngredientesPratoMontado.Text = lstPratoMontado.Items.Count.ToString();
            // todosOsOutrosCampos.Checked = false;
        }

        private void btnEspecial_Click(object sender, EventArgs e)
        {
            string IngredienteEspecial = Microsoft.VisualBasic.Interaction.InputBox
                ("Informe o nome do ingrediente especial", "Ingrediente Escpecial");
            if (IngredienteEspecial.Length > 0) // se tiver 1 ou mais caracteres
            {
                lstPratoMontado.Items.Add(IngredienteEspecial);
            }
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (txtNomePrato.Text == "") // se o campo estiver em branco
            {
                MessageBox.Show("Por favor, informe o nome do prato.");
                txtNomePrato.Focus();
                return;
            }

            if (lstPratoMontado.Items.Count == 0) // se nada for selecionado
            {
                MessageBox.Show("Não há ingredientes selecionados no prato montado.");
            }

            if (rdbViagem.Checked == true && chkAluminio.Checked == false && chkPlastica.Checked == false && chkIsopor.Checked == false)
            {
                MessageBox.Show("Por favor, selecione o tipo de embalagem.");
            }

            if (chkSuco.Checked == false && chkRefrigerante.Checked == false && chkCerveja.Checked == false && chkVinho.Checked == false)
            {
                MessageBox.Show("Por favor, selecione uma bebida.");
            }
        }
    }
}
