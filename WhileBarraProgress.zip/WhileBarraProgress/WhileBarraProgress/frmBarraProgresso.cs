﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WhileBarraProgress
{
    public partial class frmBarraProgresso : Form
    {
        public frmBarraProgresso()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int limite = 0;
            bool Elimite = int.TryParse(txtLimite.Text, out limite);

            if (!Elimite)
            {
                MessageBox.Show("Por favor, informe o limite.");
                txtLimite.Focus();
                return;
            }

            pbWhile.Maximum = limite;

            while (contador <= limite)
            {
                pbWhile.Value = contador;
                contador++;
            }
        }
    }
}
