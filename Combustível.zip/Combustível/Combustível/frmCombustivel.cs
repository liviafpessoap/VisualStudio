﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Combustível
{
    public partial class frmCombustivel : Form
    {
        public frmCombustivel()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double preco = 0, pago = 0, total = 0;

            preco = Convert.ToDouble(txtPreco.Text);
            pago = Convert.ToDouble(txtValorPago.Text);

            total = pago / preco;
            txtTotal.Text = total.ToString();

        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {
            txtTotal.ReadOnly = true;
        }
    }
}
