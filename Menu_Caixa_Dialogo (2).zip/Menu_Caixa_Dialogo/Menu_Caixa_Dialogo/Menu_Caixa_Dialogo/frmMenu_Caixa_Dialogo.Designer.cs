﻿namespace Menu_Caixa_Dialogo
{
    partial class frmMenu_Caixa_Dialogo
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuMenu = new System.Windows.Forms.MenuStrip();
            this.mnuArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemLerArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuItemSair = new System.Windows.Forms.ToolStripMenuItem();
            this.formatarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemFonte = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItemCor = new System.Windows.Forms.ToolStripMenuItem();
            this.lblSoftware = new System.Windows.Forms.Label();
            this.lstSoftware = new System.Windows.Forms.ListBox();
            this.lblArquivo = new System.Windows.Forms.Label();
            this.txtArquivo = new System.Windows.Forms.TextBox();
            this.btnLerArquivo = new System.Windows.Forms.Button();
            this.btnCor = new System.Windows.Forms.Button();
            this.btnFonte = new System.Windows.Forms.Button();
            this.mnuMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMenu
            // 
            this.mnuMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArquivo,
            this.formatarToolStripMenuItem});
            this.mnuMenu.Location = new System.Drawing.Point(0, 0);
            this.mnuMenu.Name = "mnuMenu";
            this.mnuMenu.Size = new System.Drawing.Size(539, 24);
            this.mnuMenu.TabIndex = 0;
            this.mnuMenu.Text = "menuStrip1";
            // 
            // mnuArquivo
            // 
            this.mnuArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemLerArquivo,
            this.toolStripSeparator1,
            this.mnuItemSair});
            this.mnuArquivo.Name = "mnuArquivo";
            this.mnuArquivo.Size = new System.Drawing.Size(61, 20);
            this.mnuArquivo.Text = "&Arquivo";
            // 
            // mnuItemLerArquivo
            // 
            this.mnuItemLerArquivo.Name = "mnuItemLerArquivo";
            this.mnuItemLerArquivo.Size = new System.Drawing.Size(180, 22);
            this.mnuItemLerArquivo.Text = "&Ler arquivo";
            this.mnuItemLerArquivo.Click += new System.EventHandler(this.mnuItemLerArquivo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(130, 6);
            // 
            // mnuItemSair
            // 
            this.mnuItemSair.Name = "mnuItemSair";
            this.mnuItemSair.Size = new System.Drawing.Size(133, 22);
            this.mnuItemSair.Text = "Sai&r";
            // 
            // formatarToolStripMenuItem
            // 
            this.formatarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemFonte,
            this.mnuItemCor});
            this.formatarToolStripMenuItem.Name = "formatarToolStripMenuItem";
            this.formatarToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.formatarToolStripMenuItem.Text = "&Formatar";
            // 
            // mnuItemFonte
            // 
            this.mnuItemFonte.Name = "mnuItemFonte";
            this.mnuItemFonte.Size = new System.Drawing.Size(180, 22);
            this.mnuItemFonte.Text = "&Fonte";
            this.mnuItemFonte.Click += new System.EventHandler(this.mnuItemFonte_Click);
            // 
            // mnuItemCor
            // 
            this.mnuItemCor.Name = "mnuItemCor";
            this.mnuItemCor.Size = new System.Drawing.Size(180, 22);
            this.mnuItemCor.Text = "C&or";
            this.mnuItemCor.Click += new System.EventHandler(this.mnuItemCor_Click);
            // 
            // lblSoftware
            // 
            this.lblSoftware.AutoSize = true;
            this.lblSoftware.Location = new System.Drawing.Point(26, 128);
            this.lblSoftware.Name = "lblSoftware";
            this.lblSoftware.Size = new System.Drawing.Size(52, 13);
            this.lblSoftware.TabIndex = 2;
            this.lblSoftware.Text = "Software:";
            // 
            // lstSoftware
            // 
            this.lstSoftware.FormattingEnabled = true;
            this.lstSoftware.Location = new System.Drawing.Point(26, 145);
            this.lstSoftware.Name = "lstSoftware";
            this.lstSoftware.Size = new System.Drawing.Size(156, 199);
            this.lstSoftware.TabIndex = 3;
            // 
            // lblArquivo
            // 
            this.lblArquivo.AutoSize = true;
            this.lblArquivo.Location = new System.Drawing.Point(236, 133);
            this.lblArquivo.Name = "lblArquivo";
            this.lblArquivo.Size = new System.Drawing.Size(46, 13);
            this.lblArquivo.TabIndex = 4;
            this.lblArquivo.Text = "Arquivo:";
            // 
            // txtArquivo
            // 
            this.txtArquivo.Location = new System.Drawing.Point(236, 149);
            this.txtArquivo.Multiline = true;
            this.txtArquivo.Name = "txtArquivo";
            this.txtArquivo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtArquivo.Size = new System.Drawing.Size(275, 195);
            this.txtArquivo.TabIndex = 5;
            // 
            // btnLerArquivo
            // 
            this.btnLerArquivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLerArquivo.Image = global::Menu_Caixa_Dialogo.Properties.Resources.Files_icon;
            this.btnLerArquivo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLerArquivo.Location = new System.Drawing.Point(350, 45);
            this.btnLerArquivo.Name = "btnLerArquivo";
            this.btnLerArquivo.Size = new System.Drawing.Size(142, 58);
            this.btnLerArquivo.TabIndex = 1;
            this.btnLerArquivo.Text = "&Ler Arquivo";
            this.btnLerArquivo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLerArquivo.UseVisualStyleBackColor = true;
            this.btnLerArquivo.Click += new System.EventHandler(this.btnLerArquivo_Click);
            // 
            // btnCor
            // 
            this.btnCor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCor.Image = global::Menu_Caixa_Dialogo.Properties.Resources.colors_icon;
            this.btnCor.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCor.Location = new System.Drawing.Point(209, 45);
            this.btnCor.Name = "btnCor";
            this.btnCor.Size = new System.Drawing.Size(125, 58);
            this.btnCor.TabIndex = 1;
            this.btnCor.Text = "C&or";
            this.btnCor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCor.UseVisualStyleBackColor = true;
            this.btnCor.Click += new System.EventHandler(this.btnCor_Click);
            // 
            // btnFonte
            // 
            this.btnFonte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFonte.Image = global::Menu_Caixa_Dialogo.Properties.Resources._font_icon;
            this.btnFonte.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFonte.Location = new System.Drawing.Point(54, 45);
            this.btnFonte.Name = "btnFonte";
            this.btnFonte.Size = new System.Drawing.Size(125, 58);
            this.btnFonte.TabIndex = 1;
            this.btnFonte.Text = "&Fonte";
            this.btnFonte.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFonte.UseVisualStyleBackColor = true;
            this.btnFonte.Click += new System.EventHandler(this.btnFonte_Click);
            // 
            // frmMenu_Caixa_Dialogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 368);
            this.Controls.Add(this.txtArquivo);
            this.Controls.Add(this.lblArquivo);
            this.Controls.Add(this.lstSoftware);
            this.Controls.Add(this.lblSoftware);
            this.Controls.Add(this.btnLerArquivo);
            this.Controls.Add(this.btnCor);
            this.Controls.Add(this.btnFonte);
            this.Controls.Add(this.mnuMenu);
            this.MainMenuStrip = this.mnuMenu;
            this.MaximizeBox = false;
            this.Name = "frmMenu_Caixa_Dialogo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu e Caixas de Diálogo";
            this.Load += new System.EventHandler(this.frmMenu_Caixa_Dialogo_Load);
            this.mnuMenu.ResumeLayout(false);
            this.mnuMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnuItemLerArquivo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnuItemSair;
        private System.Windows.Forms.ToolStripMenuItem formatarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuItemFonte;
        private System.Windows.Forms.ToolStripMenuItem mnuItemCor;
        private System.Windows.Forms.Button btnFonte;
        private System.Windows.Forms.Button btnCor;
        private System.Windows.Forms.Button btnLerArquivo;
        private System.Windows.Forms.Label lblSoftware;
        private System.Windows.Forms.ListBox lstSoftware;
        private System.Windows.Forms.Label lblArquivo;
        private System.Windows.Forms.TextBox txtArquivo;
    }
}

