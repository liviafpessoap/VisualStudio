﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu_Caixa_Dialogo
{
    public partial class frmMenu_Caixa_Dialogo : Form
    {
        public frmMenu_Caixa_Dialogo()
        {
            InitializeComponent();
        }

        private void frmMenu_Caixa_Dialogo_Load(object sender, EventArgs e)
        {
            // Criação do Array
            string[] softwares = new string[]
                {
                            "Windows", "Word", "Excel", "PowerPoint", "Visual Studio", "SQL Server", "Bloco de Notas", "Paint", "WordPad"
                };
            lstSoftware.DataSource = softwares;
        }

        private void btnFonte_Click(object sender, EventArgs e)
        {
            MudaFonte();
        }

        private void btnCor_Click(object sender, EventArgs e)
        {
            MudaCor();
        }

        private void btnLerArquivo_Click(object sender, EventArgs e)
        {
            LerArquivo();
        }

        private void mnuItemFonte_Click(object sender, EventArgs e)
        {
            MudaFonte();
        }

        private void mnuItemCor_Click(object sender, EventArgs e)
        {
            MudaCor();
        }

        private void mnuItemLerArquivo_Click(object sender, EventArgs e)
        {
            LerArquivo();
        }

        private void MudaFonte()
        {
            FontDialog fonte = new FontDialog();
            if (fonte.ShowDialog() == DialogResult.OK)
            {
                lstSoftware.Font = fonte.Font;
                lblSoftware.Font = fonte.Font;
            }
        }

        private void MudaCor()
        {
            ColorDialog cor = new ColorDialog();
            if (cor.ShowDialog() == DialogResult.OK)
            {
                lstSoftware.ForeColor = cor.Color;
                lblSoftware.BackColor = cor.Color;
                lstSoftware.SelectedIndex = -1;
            }
        }

        private void LerArquivo()
        {
            OpenFileDialog file = new OpenFileDialog();
            if (file.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader arquivo = new System.IO.StreamReader(file.FileName);
                txtArquivo.Text = arquivo.ReadToEnd();
            }
        }
    }
}
