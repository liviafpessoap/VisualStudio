﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cursos
{
    public partial class frmCursos : Form
    {
        public frmCursos()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            if (cbCursos.SelectedIndex == 0)
            {
                MessageBox.Show("Por favor, selecione um curso.", "Curso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cbCursos.Focus();
            }

            switch (cbCursos.SelectedIndex)
            {
                case 1:
                    lblExibir.Text = "Sistema Operacional";
                break;
                case 2:
                    lblExibir.Text = "Processador de Textos";
                break;
                case 3:
                    lblExibir.Text = "Planilha Eletrônica";
                break;
                case 4:
                    lblExibir.Text = "Apresentação em Slides";
                break;
                case 5:
                    lblExibir.Text = "Desenvolvimento de Softwares";
                break;
                case 6:
                    lblExibir.Text = "Gerenciador de Banco de Dados";
                break;
                default:
                    lblExibir.Text = "Selecione um aplicativo válido";
                    break;
            }
        }

        private void frmCursos_Load(object sender, EventArgs e)
        {
            string[] cursos = new string[]
            {
                "Selecione", "Windows", "Word", "Excel", "PowerPoint", "Visual Studio", "SQL Server"
            };
            cbCursos.DataSource = cursos;
        }
    }
}
